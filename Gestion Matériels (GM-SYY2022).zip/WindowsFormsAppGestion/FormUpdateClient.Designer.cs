﻿namespace WindowsFormsAppGestion
{
    partial class FormUpdateClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxTelClient = new System.Windows.Forms.TextBox();
            this.labelTelClient = new System.Windows.Forms.Label();
            this.textBoxMailClient = new System.Windows.Forms.TextBox();
            this.labelMailClient = new System.Windows.Forms.Label();
            this.textBoxAdresseClient = new System.Windows.Forms.TextBox();
            this.labelAdresseClient = new System.Windows.Forms.Label();
            this.textBoxNumClient = new System.Windows.Forms.TextBox();
            this.labelNumClient = new System.Windows.Forms.Label();
            this.textBoxNomClient = new System.Windows.Forms.TextBox();
            this.labelNomClient = new System.Windows.Forms.Label();
            this.labelTitleUpdateClient = new System.Windows.Forms.Label();
            this.buttonCancelClient = new System.Windows.Forms.Button();
            this.buttonUpdateClient = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxTelClient
            // 
            this.textBoxTelClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTelClient.Location = new System.Drawing.Point(46, 352);
            this.textBoxTelClient.Name = "textBoxTelClient";
            this.textBoxTelClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxTelClient.TabIndex = 30;
            // 
            // labelTelClient
            // 
            this.labelTelClient.AutoSize = true;
            this.labelTelClient.Location = new System.Drawing.Point(45, 333);
            this.labelTelClient.Name = "labelTelClient";
            this.labelTelClient.Size = new System.Drawing.Size(73, 16);
            this.labelTelClient.TabIndex = 29;
            this.labelTelClient.Text = "Téléphone";
            // 
            // textBoxMailClient
            // 
            this.textBoxMailClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMailClient.Location = new System.Drawing.Point(46, 285);
            this.textBoxMailClient.Name = "textBoxMailClient";
            this.textBoxMailClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxMailClient.TabIndex = 28;
            // 
            // labelMailClient
            // 
            this.labelMailClient.AutoSize = true;
            this.labelMailClient.Location = new System.Drawing.Point(45, 266);
            this.labelMailClient.Name = "labelMailClient";
            this.labelMailClient.Size = new System.Drawing.Size(98, 16);
            this.labelMailClient.TabIndex = 27;
            this.labelMailClient.Text = "Adresse e-mail";
            // 
            // textBoxAdresseClient
            // 
            this.textBoxAdresseClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAdresseClient.Location = new System.Drawing.Point(46, 219);
            this.textBoxAdresseClient.Name = "textBoxAdresseClient";
            this.textBoxAdresseClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxAdresseClient.TabIndex = 26;
            // 
            // labelAdresseClient
            // 
            this.labelAdresseClient.AutoSize = true;
            this.labelAdresseClient.Location = new System.Drawing.Point(45, 200);
            this.labelAdresseClient.Name = "labelAdresseClient";
            this.labelAdresseClient.Size = new System.Drawing.Size(58, 16);
            this.labelAdresseClient.TabIndex = 25;
            this.labelAdresseClient.Text = "Adresse";
            // 
            // textBoxNumClient
            // 
            this.textBoxNumClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNumClient.Location = new System.Drawing.Point(46, 152);
            this.textBoxNumClient.Name = "textBoxNumClient";
            this.textBoxNumClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxNumClient.TabIndex = 24;
            // 
            // labelNumClient
            // 
            this.labelNumClient.AutoSize = true;
            this.labelNumClient.Location = new System.Drawing.Point(45, 133);
            this.labelNumClient.Name = "labelNumClient";
            this.labelNumClient.Size = new System.Drawing.Size(89, 16);
            this.labelNumClient.TabIndex = 23;
            this.labelNumClient.Text = "Numéro client";
            // 
            // textBoxNomClient
            // 
            this.textBoxNomClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNomClient.Location = new System.Drawing.Point(46, 94);
            this.textBoxNomClient.Name = "textBoxNomClient";
            this.textBoxNomClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxNomClient.TabIndex = 22;
            // 
            // labelNomClient
            // 
            this.labelNomClient.AutoSize = true;
            this.labelNomClient.Location = new System.Drawing.Point(45, 75);
            this.labelNomClient.Name = "labelNomClient";
            this.labelNomClient.Size = new System.Drawing.Size(39, 16);
            this.labelNomClient.TabIndex = 21;
            this.labelNomClient.Text = "Nom ";
            // 
            // labelTitleUpdateClient
            // 
            this.labelTitleUpdateClient.AutoSize = true;
            this.labelTitleUpdateClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleUpdateClient.Location = new System.Drawing.Point(154, 29);
            this.labelTitleUpdateClient.Name = "labelTitleUpdateClient";
            this.labelTitleUpdateClient.Size = new System.Drawing.Size(176, 25);
            this.labelTitleUpdateClient.TabIndex = 20;
            this.labelTitleUpdateClient.Text = "Modifier un client";
            // 
            // buttonCancelClient
            // 
            this.buttonCancelClient.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancelClient.Location = new System.Drawing.Point(363, 426);
            this.buttonCancelClient.Name = "buttonCancelClient";
            this.buttonCancelClient.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelClient.TabIndex = 19;
            this.buttonCancelClient.Text = "Annuler";
            this.buttonCancelClient.UseVisualStyleBackColor = true;
            // 
            // buttonUpdateClient
            // 
            this.buttonUpdateClient.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonUpdateClient.Location = new System.Drawing.Point(282, 426);
            this.buttonUpdateClient.Name = "buttonUpdateClient";
            this.buttonUpdateClient.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdateClient.TabIndex = 18;
            this.buttonUpdateClient.Text = "Valider";
            this.buttonUpdateClient.UseVisualStyleBackColor = true;
            this.buttonUpdateClient.Click += new System.EventHandler(this.buttonUpdateClient_Click);
            // 
            // FormUpdateClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 478);
            this.Controls.Add(this.textBoxTelClient);
            this.Controls.Add(this.labelTelClient);
            this.Controls.Add(this.textBoxMailClient);
            this.Controls.Add(this.labelMailClient);
            this.Controls.Add(this.textBoxAdresseClient);
            this.Controls.Add(this.labelAdresseClient);
            this.Controls.Add(this.textBoxNumClient);
            this.Controls.Add(this.labelNumClient);
            this.Controls.Add(this.textBoxNomClient);
            this.Controls.Add(this.labelNomClient);
            this.Controls.Add(this.labelTitleUpdateClient);
            this.Controls.Add(this.buttonCancelClient);
            this.Controls.Add(this.buttonUpdateClient);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormUpdateClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Modifier un client";
            this.Load += new System.EventHandler(this.FormUpdateClient_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxTelClient;
        private System.Windows.Forms.Label labelTelClient;
        private System.Windows.Forms.TextBox textBoxMailClient;
        private System.Windows.Forms.Label labelMailClient;
        private System.Windows.Forms.TextBox textBoxAdresseClient;
        private System.Windows.Forms.Label labelAdresseClient;
        private System.Windows.Forms.TextBox textBoxNumClient;
        private System.Windows.Forms.Label labelNumClient;
        private System.Windows.Forms.TextBox textBoxNomClient;
        private System.Windows.Forms.Label labelNomClient;
        private System.Windows.Forms.Label labelTitleUpdateClient;
        private System.Windows.Forms.Button buttonCancelClient;
        private System.Windows.Forms.Button buttonUpdateClient;
    }
}