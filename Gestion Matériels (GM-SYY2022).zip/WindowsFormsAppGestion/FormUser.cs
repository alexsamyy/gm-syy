﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class FormUser : Form
    {
        private bool addUser;
        private helper helper = new helper();
        private ClassHash hash = new ClassHash();
        public string login, hash_pwd;
        public FormUser()
        {
            
        }
        public FormUser(string use)
        {
            InitializeComponent();
            if (use == "add")
            {
                addUser = true;
            }
            else
            {
                if (use == "update")
                {
                    addUser = false;
                }
                else
                {
                    return;
                }
            }
        }

        private void buttonAddUser_Click(object sender, EventArgs e)
        {
            this.login = textBoxAddUserLogin.Text;

            // HASH INPUT PASSWORD
            SHA256 sha256Hash = SHA256.Create();
            hash_pwd = hash.getHash(sha256Hash, textBoxAddUserPWD.Text);
        }

        private void FormAdminAdd_Load(object sender, EventArgs e)
        {
            if (addUser == false)
            {
                textBoxAddUserLogin.Text = FormAdmin.login;
            }
        }
    }
}
