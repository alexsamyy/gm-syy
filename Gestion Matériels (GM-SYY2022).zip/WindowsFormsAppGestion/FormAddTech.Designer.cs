﻿namespace WindowsFormsAppGestion
{
    partial class FormAddTech
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAddTech = new System.Windows.Forms.Button();
            this.buttonCancelTech = new System.Windows.Forms.Button();
            this.labelTitleAddTech = new System.Windows.Forms.Label();
            this.labelAddTech = new System.Windows.Forms.Label();
            this.textBoxAddTech = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonAddTech
            // 
            this.buttonAddTech.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonAddTech.Location = new System.Drawing.Point(249, 157);
            this.buttonAddTech.Name = "buttonAddTech";
            this.buttonAddTech.Size = new System.Drawing.Size(75, 23);
            this.buttonAddTech.TabIndex = 0;
            this.buttonAddTech.Text = "Valider";
            this.buttonAddTech.UseVisualStyleBackColor = true;
            this.buttonAddTech.Click += new System.EventHandler(this.buttonAddTech_Click);
            // 
            // buttonCancelTech
            // 
            this.buttonCancelTech.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancelTech.Location = new System.Drawing.Point(330, 157);
            this.buttonCancelTech.Name = "buttonCancelTech";
            this.buttonCancelTech.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelTech.TabIndex = 1;
            this.buttonCancelTech.Text = "Annuler";
            this.buttonCancelTech.UseVisualStyleBackColor = true;
            // 
            // labelTitleAddTech
            // 
            this.labelTitleAddTech.AutoSize = true;
            this.labelTitleAddTech.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleAddTech.Location = new System.Drawing.Point(96, 9);
            this.labelTitleAddTech.Name = "labelTitleAddTech";
            this.labelTitleAddTech.Size = new System.Drawing.Size(215, 25);
            this.labelTitleAddTech.TabIndex = 2;
            this.labelTitleAddTech.Text = "Ajouter un technicien";
            // 
            // labelAddTech
            // 
            this.labelAddTech.AutoSize = true;
            this.labelAddTech.Location = new System.Drawing.Point(12, 57);
            this.labelAddTech.Name = "labelAddTech";
            this.labelAddTech.Size = new System.Drawing.Size(39, 16);
            this.labelAddTech.TabIndex = 3;
            this.labelAddTech.Text = "Nom ";
            // 
            // textBoxAddTech
            // 
            this.textBoxAddTech.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAddTech.Location = new System.Drawing.Point(13, 76);
            this.textBoxAddTech.Name = "textBoxAddTech";
            this.textBoxAddTech.Size = new System.Drawing.Size(392, 27);
            this.textBoxAddTech.TabIndex = 4;
            // 
            // FormAddTech
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 192);
            this.Controls.Add(this.textBoxAddTech);
            this.Controls.Add(this.labelAddTech);
            this.Controls.Add(this.labelTitleAddTech);
            this.Controls.Add(this.buttonCancelTech);
            this.Controls.Add(this.buttonAddTech);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAddTech";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Ajouter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAddTech;
        private System.Windows.Forms.Button buttonCancelTech;
        private System.Windows.Forms.Label labelTitleAddTech;
        private System.Windows.Forms.Label labelAddTech;
        private System.Windows.Forms.TextBox textBoxAddTech;
    }
}