﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class FormAdmin : Form
    {
        private bool isUtilisateur;
        private helper helper = new helper();
        public FormAdmin()
        {

        }
        public FormAdmin(string selectedBtn)
        {
            InitializeComponent();
            if (selectedBtn == "utilisateur")
            {
                isUtilisateur = true;
            }
            else
            {
                if (selectedBtn == "marque")
                {
                    isUtilisateur = false;
                }
                else
                {
                    return;
                }
            }
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {
            if (isUtilisateur)
            {
                displayDataGrid("SELECT * FROM ADMINISTRATEUR");

                // HIDE HASHED PWD COLUMN
                dataGridViewAdmin.Columns[2].Visible = false;
            }
            else
            {
                displayDataGrid("SELECT * FROM MARQUE");
            }
        }

        private void buttonAdminAdd_Click(object sender, EventArgs e)
        {
            if (isUtilisateur)
            {
                FormUser formAdminAdd = new FormUser("add");
                formAdminAdd.ShowDialog();
                if (formAdminAdd.DialogResult == DialogResult.OK)
                {
                    SqlDataReader sqlDr =
                    helper.selectQuery("SELECT * FROM ADMINISTRATEUR WHERE LOGIN = '" + formAdminAdd.login + "';");

                    if (sqlDr.Read())
                    {
                        helper.conn.Close();
                        MessageBox.Show("Cet utilisateur existe déjà !");
                        return;
                    }
                    else
                    {
                        helper.conn.Close();
                        if ((formAdminAdd.hash_pwd == "") || (formAdminAdd.login == ""))
                        {
                            MessageBox.Show("Veuillez remplir les informations nécessaires !");
                            return;
                        }

                        helper.query("INSERT INTO ADMINISTRATEUR(LOGIN, MDP)" +
                        " VALUES('" + formAdminAdd.login + "','" + formAdminAdd.hash_pwd + "');");

                        displayDataGrid("SELECT * FROM ADMINISTRATEUR");
                    }
                }
            }
            else
            {
                FormMarque formAdminAdd = new FormMarque("add");
                formAdminAdd.ShowDialog();
                if (formAdminAdd.DialogResult == DialogResult.OK)
                {
                    if (formAdminAdd.nom == "")
                    {
                        MessageBox.Show("Veuillez remplir les informations nécessaires !");
                        return;
                    }

                    helper.query("INSERT INTO MARQUE(NOM)" +
                    " VALUES('" + formAdminAdd.nom + "');");

                    displayDataGrid("SELECT * FROM MARQUE");
                    
                }
            }
            
        }

        public static string login, nom;
        public static int id_user, id_brand;
        private void dataGridViewAdmin_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                dataGridViewAdmin.ClearSelection();
                buttonAdminUpdate.Enabled = false;
                buttonAdminDelete.Enabled = false;
                return;
            }
            
            if (isUtilisateur)
            {
                id_user = Convert.ToInt32(dataGridViewAdmin.Rows[e.RowIndex].Cells[0].Value);
                login = dataGridViewAdmin.Rows[e.RowIndex].Cells[1].Value.ToString();
            }
            else
            {
                id_brand = Convert.ToInt32(dataGridViewAdmin.Rows[e.RowIndex].Cells[0].Value);
                nom = dataGridViewAdmin.Rows[e.RowIndex].Cells[1].Value.ToString();
            }
            
            buttonAdminUpdate.Enabled = true;
            buttonAdminDelete.Enabled = true;

        }
        private void buttonAdminUpdate_Click(object sender, EventArgs e)
        {
            if (isUtilisateur)
            {
                FormUser formAdminAdd = new FormUser("update");
                formAdminAdd.ShowDialog();

                if (formAdminAdd.DialogResult == DialogResult.OK)
                {
                    if ((formAdminAdd.hash_pwd == "") || (formAdminAdd.login == ""))
                    {
                        MessageBox.Show("Veuillez remplir les informations nécessaires !");
                        return;
                    }

                    helper.query("UPDATE ADMINISTRATEUR SET " +
                       "LOGIN = '" + formAdminAdd.login +
                       "', MDP = '" + formAdminAdd.hash_pwd +
                       "' WHERE ID_ADMIN = '" + id_user + "';");

                    displayDataGrid("SELECT * FROM ADMINISTRATEUR");
                }
            }
            else
            {
                FormMarque formAdminAdd = new FormMarque("update");
                formAdminAdd.ShowDialog();

                if (formAdminAdd.DialogResult == DialogResult.OK)
                {
                    if (formAdminAdd.nom == "")
                    {
                        MessageBox.Show("Veuillez remplir les informations nécessaires !");
                        return;
                    }

                    helper.query("UPDATE MARQUE SET " +
                       "NOM = '" + formAdminAdd.nom +
                       "' WHERE ID_MARQUE = '" + id_brand + "';");

                    displayDataGrid("SELECT * FROM MARQUE");
                }
            }
        }

        private void buttonAdminDelete_Click(object sender, EventArgs e)
        {
            if (isUtilisateur)
            {
                helper.query
                        ("DELETE FROM ADMINISTRATEUR WHERE ID_ADMIN = '" + id_user + "';");

                displayDataGrid("SELECT * FROM ADMINISTRATEUR");
            }
            else
            {
                helper.query
                        ("DELETE FROM MARQUE WHERE ID_MARQUE = '" + id_brand + "';");

                displayDataGrid("SELECT * FROM MARQUE");
            }
            
        }

        // ------------------ METHOD TO FILL DATAGRIDVIEW -------------------------
        private void displayDataGrid(string rq)
        {
            SqlDataReader dr =
                helper.selectQuery(rq);

            var dt = new DataTable();
            dt.Load(dr);
            dataGridViewAdmin.DataSource = dt;

            helper.conn.Close();

            dataGridViewAdmin.ClearSelection();

            buttonAdminUpdate.Enabled = false;
            buttonAdminDelete.Enabled = false;
        }
    }
}
