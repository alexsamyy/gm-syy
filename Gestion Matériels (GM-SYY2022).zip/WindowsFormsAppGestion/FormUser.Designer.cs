﻿namespace WindowsFormsAppGestion
{
    partial class FormUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxAddUserLogin = new System.Windows.Forms.TextBox();
            this.labelLogin = new System.Windows.Forms.Label();
            this.labelTitleAddAdmin = new System.Windows.Forms.Label();
            this.buttonCancelUser = new System.Windows.Forms.Button();
            this.buttonAddUser = new System.Windows.Forms.Button();
            this.textBoxAddUserPWD = new System.Windows.Forms.TextBox();
            this.labelPWD = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxAddUserLogin
            // 
            this.textBoxAddUserLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAddUserLogin.Location = new System.Drawing.Point(44, 92);
            this.textBoxAddUserLogin.Name = "textBoxAddUserLogin";
            this.textBoxAddUserLogin.Size = new System.Drawing.Size(392, 27);
            this.textBoxAddUserLogin.TabIndex = 9;
            // 
            // labelLogin
            // 
            this.labelLogin.AutoSize = true;
            this.labelLogin.Location = new System.Drawing.Point(43, 73);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(40, 16);
            this.labelLogin.TabIndex = 8;
            this.labelLogin.Text = "Login";
            // 
            // labelTitleAddAdmin
            // 
            this.labelTitleAddAdmin.AutoSize = true;
            this.labelTitleAddAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleAddAdmin.Location = new System.Drawing.Point(127, 25);
            this.labelTitleAddAdmin.Name = "labelTitleAddAdmin";
            this.labelTitleAddAdmin.Size = new System.Drawing.Size(247, 25);
            this.labelTitleAddAdmin.TabIndex = 7;
            this.labelTitleAddAdmin.Text = "Paramétrer un utilisateur";
            // 
            // buttonCancelUser
            // 
            this.buttonCancelUser.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancelUser.Location = new System.Drawing.Point(361, 250);
            this.buttonCancelUser.Name = "buttonCancelUser";
            this.buttonCancelUser.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelUser.TabIndex = 6;
            this.buttonCancelUser.Text = "Annuler";
            this.buttonCancelUser.UseVisualStyleBackColor = true;
            // 
            // buttonAddUser
            // 
            this.buttonAddUser.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonAddUser.Location = new System.Drawing.Point(280, 250);
            this.buttonAddUser.Name = "buttonAddUser";
            this.buttonAddUser.Size = new System.Drawing.Size(75, 23);
            this.buttonAddUser.TabIndex = 5;
            this.buttonAddUser.Text = "Valider";
            this.buttonAddUser.UseVisualStyleBackColor = true;
            this.buttonAddUser.Click += new System.EventHandler(this.buttonAddUser_Click);
            // 
            // textBoxAddUserPWD
            // 
            this.textBoxAddUserPWD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAddUserPWD.Location = new System.Drawing.Point(44, 166);
            this.textBoxAddUserPWD.Name = "textBoxAddUserPWD";
            this.textBoxAddUserPWD.Size = new System.Drawing.Size(392, 27);
            this.textBoxAddUserPWD.TabIndex = 10;
            // 
            // labelPWD
            // 
            this.labelPWD.AutoSize = true;
            this.labelPWD.Location = new System.Drawing.Point(43, 147);
            this.labelPWD.Name = "labelPWD";
            this.labelPWD.Size = new System.Drawing.Size(89, 16);
            this.labelPWD.TabIndex = 11;
            this.labelPWD.Text = "Mot de passe";
            // 
            // FormUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 294);
            this.Controls.Add(this.labelPWD);
            this.Controls.Add(this.textBoxAddUserPWD);
            this.Controls.Add(this.textBoxAddUserLogin);
            this.Controls.Add(this.labelLogin);
            this.Controls.Add(this.labelTitleAddAdmin);
            this.Controls.Add(this.buttonCancelUser);
            this.Controls.Add(this.buttonAddUser);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Administrateur";
            this.Load += new System.EventHandler(this.FormAdminAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxAddUserLogin;
        private System.Windows.Forms.Label labelLogin;
        private System.Windows.Forms.Label labelTitleAddAdmin;
        private System.Windows.Forms.Button buttonCancelUser;
        private System.Windows.Forms.Button buttonAddUser;
        private System.Windows.Forms.TextBox textBoxAddUserPWD;
        private System.Windows.Forms.Label labelPWD;
    }
}