﻿namespace WindowsFormsAppGestion
{
    partial class FormUpdateMateriel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxClient = new System.Windows.Forms.ComboBox();
            this.comboBoxType = new System.Windows.Forms.ComboBox();
            this.comboBoxMarque = new System.Windows.Forms.ComboBox();
            this.dateTimePickerInstall = new System.Windows.Forms.DateTimePicker();
            this.labelMat_Client = new System.Windows.Forms.Label();
            this.labelMat_Type = new System.Windows.Forms.Label();
            this.labelMat_Marque = new System.Windows.Forms.Label();
            this.labelMat_MTBF = new System.Windows.Forms.Label();
            this.labelMat_Install = new System.Windows.Forms.Label();
            this.textBoxNserie = new System.Windows.Forms.TextBox();
            this.labelMat_Nserie = new System.Windows.Forms.Label();
            this.textBoxNom = new System.Windows.Forms.TextBox();
            this.labelMat_Nom = new System.Windows.Forms.Label();
            this.labelTitleUpdateMat = new System.Windows.Forms.Label();
            this.buttonCancelMat = new System.Windows.Forms.Button();
            this.buttonUpdateMateriel = new System.Windows.Forms.Button();
            this.numericUpDownMTBF = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMTBF)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxClient
            // 
            this.comboBoxClient.FormattingEnabled = true;
            this.comboBoxClient.Items.AddRange(new object[] {
            "Choisir un client"});
            this.comboBoxClient.Location = new System.Drawing.Point(15, 447);
            this.comboBoxClient.Name = "comboBoxClient";
            this.comboBoxClient.Size = new System.Drawing.Size(392, 24);
            this.comboBoxClient.TabIndex = 48;
            // 
            // comboBoxType
            // 
            this.comboBoxType.FormattingEnabled = true;
            this.comboBoxType.Items.AddRange(new object[] {
            "Choisir un type"});
            this.comboBoxType.Location = new System.Drawing.Point(15, 383);
            this.comboBoxType.Name = "comboBoxType";
            this.comboBoxType.Size = new System.Drawing.Size(392, 24);
            this.comboBoxType.TabIndex = 47;
            // 
            // comboBoxMarque
            // 
            this.comboBoxMarque.FormattingEnabled = true;
            this.comboBoxMarque.Items.AddRange(new object[] {
            "Choisir une marque"});
            this.comboBoxMarque.Location = new System.Drawing.Point(15, 323);
            this.comboBoxMarque.Name = "comboBoxMarque";
            this.comboBoxMarque.Size = new System.Drawing.Size(392, 24);
            this.comboBoxMarque.TabIndex = 46;
            // 
            // dateTimePickerInstall
            // 
            this.dateTimePickerInstall.Location = new System.Drawing.Point(15, 203);
            this.dateTimePickerInstall.Name = "dateTimePickerInstall";
            this.dateTimePickerInstall.Size = new System.Drawing.Size(248, 22);
            this.dateTimePickerInstall.TabIndex = 45;
            // 
            // labelMat_Client
            // 
            this.labelMat_Client.AutoSize = true;
            this.labelMat_Client.Location = new System.Drawing.Point(14, 428);
            this.labelMat_Client.Name = "labelMat_Client";
            this.labelMat_Client.Size = new System.Drawing.Size(40, 16);
            this.labelMat_Client.TabIndex = 44;
            this.labelMat_Client.Text = "Client";
            // 
            // labelMat_Type
            // 
            this.labelMat_Type.AutoSize = true;
            this.labelMat_Type.Location = new System.Drawing.Point(14, 364);
            this.labelMat_Type.Name = "labelMat_Type";
            this.labelMat_Type.Size = new System.Drawing.Size(39, 16);
            this.labelMat_Type.TabIndex = 43;
            this.labelMat_Type.Text = "Type";
            // 
            // labelMat_Marque
            // 
            this.labelMat_Marque.AutoSize = true;
            this.labelMat_Marque.Location = new System.Drawing.Point(14, 304);
            this.labelMat_Marque.Name = "labelMat_Marque";
            this.labelMat_Marque.Size = new System.Drawing.Size(53, 16);
            this.labelMat_Marque.TabIndex = 42;
            this.labelMat_Marque.Text = "Marque";
            // 
            // labelMat_MTBF
            // 
            this.labelMat_MTBF.AutoSize = true;
            this.labelMat_MTBF.Location = new System.Drawing.Point(14, 243);
            this.labelMat_MTBF.Name = "labelMat_MTBF";
            this.labelMat_MTBF.Size = new System.Drawing.Size(44, 16);
            this.labelMat_MTBF.TabIndex = 41;
            this.labelMat_MTBF.Text = "MTBF";
            // 
            // labelMat_Install
            // 
            this.labelMat_Install.AutoSize = true;
            this.labelMat_Install.Location = new System.Drawing.Point(14, 184);
            this.labelMat_Install.Name = "labelMat_Install";
            this.labelMat_Install.Size = new System.Drawing.Size(113, 16);
            this.labelMat_Install.TabIndex = 40;
            this.labelMat_Install.Text = "Date d\'installation";
            // 
            // textBoxNserie
            // 
            this.textBoxNserie.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNserie.Location = new System.Drawing.Point(15, 139);
            this.textBoxNserie.Name = "textBoxNserie";
            this.textBoxNserie.Size = new System.Drawing.Size(392, 27);
            this.textBoxNserie.TabIndex = 39;
            // 
            // labelMat_Nserie
            // 
            this.labelMat_Nserie.AutoSize = true;
            this.labelMat_Nserie.Location = new System.Drawing.Point(14, 120);
            this.labelMat_Nserie.Name = "labelMat_Nserie";
            this.labelMat_Nserie.Size = new System.Drawing.Size(73, 16);
            this.labelMat_Nserie.TabIndex = 38;
            this.labelMat_Nserie.Text = "N° de série";
            // 
            // textBoxNom
            // 
            this.textBoxNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNom.Location = new System.Drawing.Point(15, 84);
            this.textBoxNom.Name = "textBoxNom";
            this.textBoxNom.Size = new System.Drawing.Size(392, 27);
            this.textBoxNom.TabIndex = 37;
            // 
            // labelMat_Nom
            // 
            this.labelMat_Nom.AutoSize = true;
            this.labelMat_Nom.Location = new System.Drawing.Point(14, 65);
            this.labelMat_Nom.Name = "labelMat_Nom";
            this.labelMat_Nom.Size = new System.Drawing.Size(39, 16);
            this.labelMat_Nom.TabIndex = 36;
            this.labelMat_Nom.Text = "Nom ";
            // 
            // labelTitleUpdateMat
            // 
            this.labelTitleUpdateMat.AutoSize = true;
            this.labelTitleUpdateMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleUpdateMat.Location = new System.Drawing.Point(108, 15);
            this.labelTitleUpdateMat.Name = "labelTitleUpdateMat";
            this.labelTitleUpdateMat.Size = new System.Drawing.Size(201, 25);
            this.labelTitleUpdateMat.TabIndex = 35;
            this.labelTitleUpdateMat.Text = "Modifier un matériel";
            // 
            // buttonCancelMat
            // 
            this.buttonCancelMat.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancelMat.Location = new System.Drawing.Point(332, 517);
            this.buttonCancelMat.Name = "buttonCancelMat";
            this.buttonCancelMat.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelMat.TabIndex = 34;
            this.buttonCancelMat.Text = "Annuler";
            this.buttonCancelMat.UseVisualStyleBackColor = true;
            // 
            // buttonUpdateMateriel
            // 
            this.buttonUpdateMateriel.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonUpdateMateriel.Location = new System.Drawing.Point(251, 517);
            this.buttonUpdateMateriel.Name = "buttonUpdateMateriel";
            this.buttonUpdateMateriel.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdateMateriel.TabIndex = 33;
            this.buttonUpdateMateriel.Text = "Valider";
            this.buttonUpdateMateriel.UseVisualStyleBackColor = true;
            this.buttonUpdateMateriel.Click += new System.EventHandler(this.buttonUpdateMateriel_Click);
            // 
            // numericUpDownMTBF
            // 
            this.numericUpDownMTBF.Location = new System.Drawing.Point(15, 262);
            this.numericUpDownMTBF.Name = "numericUpDownMTBF";
            this.numericUpDownMTBF.Size = new System.Drawing.Size(248, 22);
            this.numericUpDownMTBF.TabIndex = 49;
            // 
            // FormUpdateMateriel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 555);
            this.Controls.Add(this.numericUpDownMTBF);
            this.Controls.Add(this.comboBoxClient);
            this.Controls.Add(this.comboBoxType);
            this.Controls.Add(this.comboBoxMarque);
            this.Controls.Add(this.dateTimePickerInstall);
            this.Controls.Add(this.labelMat_Client);
            this.Controls.Add(this.labelMat_Type);
            this.Controls.Add(this.labelMat_Marque);
            this.Controls.Add(this.labelMat_MTBF);
            this.Controls.Add(this.labelMat_Install);
            this.Controls.Add(this.textBoxNserie);
            this.Controls.Add(this.labelMat_Nserie);
            this.Controls.Add(this.textBoxNom);
            this.Controls.Add(this.labelMat_Nom);
            this.Controls.Add(this.labelTitleUpdateMat);
            this.Controls.Add(this.buttonCancelMat);
            this.Controls.Add(this.buttonUpdateMateriel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormUpdateMateriel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Modifier un matériel";
            this.Load += new System.EventHandler(this.FormUpdateMateriel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMTBF)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox comboBoxClient;
        private System.Windows.Forms.ComboBox comboBoxType;
        private System.Windows.Forms.ComboBox comboBoxMarque;
        private System.Windows.Forms.DateTimePicker dateTimePickerInstall;
        private System.Windows.Forms.Label labelMat_Client;
        private System.Windows.Forms.Label labelMat_Type;
        private System.Windows.Forms.Label labelMat_Marque;
        private System.Windows.Forms.Label labelMat_MTBF;
        private System.Windows.Forms.Label labelMat_Install;
        private System.Windows.Forms.TextBox textBoxNserie;
        private System.Windows.Forms.Label labelMat_Nserie;
        private System.Windows.Forms.TextBox textBoxNom;
        private System.Windows.Forms.Label labelMat_Nom;
        private System.Windows.Forms.Label labelTitleUpdateMat;
        private System.Windows.Forms.Button buttonCancelMat;
        private System.Windows.Forms.Button buttonUpdateMateriel;
        private System.Windows.Forms.NumericUpDown numericUpDownMTBF;
    }
}