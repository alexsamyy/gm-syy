﻿namespace WindowsFormsAppGestion
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewAdmin = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonAdminAdd = new System.Windows.Forms.Button();
            this.buttonAdminUpdate = new System.Windows.Forms.Button();
            this.buttonAdminDelete = new System.Windows.Forms.Button();
            this.buttonAdminOk = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdmin)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewAdmin
            // 
            this.dataGridViewAdmin.AllowUserToAddRows = false;
            this.dataGridViewAdmin.AllowUserToDeleteRows = false;
            this.dataGridViewAdmin.AllowUserToOrderColumns = true;
            this.dataGridViewAdmin.AllowUserToResizeColumns = false;
            this.dataGridViewAdmin.AllowUserToResizeRows = false;
            this.dataGridViewAdmin.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewAdmin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAdmin.Location = new System.Drawing.Point(12, 12);
            this.dataGridViewAdmin.MultiSelect = false;
            this.dataGridViewAdmin.Name = "dataGridViewAdmin";
            this.dataGridViewAdmin.RowHeadersVisible = false;
            this.dataGridViewAdmin.RowHeadersWidth = 51;
            this.dataGridViewAdmin.RowTemplate.Height = 24;
            this.dataGridViewAdmin.Size = new System.Drawing.Size(620, 426);
            this.dataGridViewAdmin.TabIndex = 0;
            this.dataGridViewAdmin.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewAdmin_CellMouseUp);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.buttonAdminAdd, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.buttonAdminUpdate, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.buttonAdminDelete, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(638, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(150, 131);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // buttonAdminAdd
            // 
            this.buttonAdminAdd.Location = new System.Drawing.Point(3, 3);
            this.buttonAdminAdd.Name = "buttonAdminAdd";
            this.buttonAdminAdd.Size = new System.Drawing.Size(144, 38);
            this.buttonAdminAdd.TabIndex = 0;
            this.buttonAdminAdd.Text = "AJOUTER";
            this.buttonAdminAdd.UseVisualStyleBackColor = true;
            this.buttonAdminAdd.Click += new System.EventHandler(this.buttonAdminAdd_Click);
            // 
            // buttonAdminUpdate
            // 
            this.buttonAdminUpdate.Location = new System.Drawing.Point(3, 47);
            this.buttonAdminUpdate.Name = "buttonAdminUpdate";
            this.buttonAdminUpdate.Size = new System.Drawing.Size(144, 38);
            this.buttonAdminUpdate.TabIndex = 1;
            this.buttonAdminUpdate.Text = "MODIFIER";
            this.buttonAdminUpdate.UseVisualStyleBackColor = true;
            this.buttonAdminUpdate.Click += new System.EventHandler(this.buttonAdminUpdate_Click);
            // 
            // buttonAdminDelete
            // 
            this.buttonAdminDelete.Location = new System.Drawing.Point(3, 91);
            this.buttonAdminDelete.Name = "buttonAdminDelete";
            this.buttonAdminDelete.Size = new System.Drawing.Size(144, 37);
            this.buttonAdminDelete.TabIndex = 2;
            this.buttonAdminDelete.Text = "SUPPRIMER";
            this.buttonAdminDelete.UseVisualStyleBackColor = true;
            this.buttonAdminDelete.Click += new System.EventHandler(this.buttonAdminDelete_Click);
            // 
            // buttonAdminOk
            // 
            this.buttonAdminOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonAdminOk.Location = new System.Drawing.Point(641, 414);
            this.buttonAdminOk.Name = "buttonAdminOk";
            this.buttonAdminOk.Size = new System.Drawing.Size(144, 23);
            this.buttonAdminOk.TabIndex = 2;
            this.buttonAdminOk.Text = "OK";
            this.buttonAdminOk.UseVisualStyleBackColor = true;
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonAdminOk);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.dataGridViewAdmin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Administrateur";
            this.Load += new System.EventHandler(this.FormAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdmin)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewAdmin;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button buttonAdminAdd;
        private System.Windows.Forms.Button buttonAdminUpdate;
        private System.Windows.Forms.Button buttonAdminDelete;
        private System.Windows.Forms.Button buttonAdminOk;
    }
}