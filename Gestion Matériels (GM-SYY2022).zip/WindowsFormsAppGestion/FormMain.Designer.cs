﻿namespace WindowsFormsAppGestion
{
    partial class FormMain
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.utilisateurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seDéconnecterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitterGMSYY2022ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rafraîchirLaPageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.administrateurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marquesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.utilisateursToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelTechnicien = new System.Windows.Forms.Label();
            this.labelClient = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelConnected = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelAdminMode = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelTimeRefresh = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelSelectedCell = new System.Windows.Forms.ToolStripStatusLabel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonDelTech = new System.Windows.Forms.Button();
            this.buttonModifyTech = new System.Windows.Forms.Button();
            this.buttonAddTech = new System.Windows.Forms.Button();
            this.buttonDelClient = new System.Windows.Forms.Button();
            this.buttonModifyClient = new System.Windows.Forms.Button();
            this.buttonAddClient = new System.Windows.Forms.Button();
            this.listBoxClient = new System.Windows.Forms.ListBox();
            this.listBoxTech = new System.Windows.Forms.ListBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonAddInterv = new System.Windows.Forms.Button();
            this.textBoxIntervCom = new System.Windows.Forms.TextBox();
            this.labelNewIntervCom = new System.Windows.Forms.Label();
            this.buttonIntervModify = new System.Windows.Forms.Button();
            this.buttonDeleteInterv = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridViewOldInterv = new System.Windows.Forms.DataGridView();
            this.labelIntervPrevues = new System.Windows.Forms.Label();
            this.labelOldInterv = new System.Windows.Forms.Label();
            this.dataGridViewNewInterv = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.labelIntervDate = new System.Windows.Forms.Label();
            this.labelIntervTech = new System.Windows.Forms.Label();
            this.labelIntervMat = new System.Windows.Forms.Label();
            this.dateTimePickerInterv = new System.Windows.Forms.DateTimePicker();
            this.comboBoxIntervTech = new System.Windows.Forms.ComboBox();
            this.comboBoxIntervMat = new System.Windows.Forms.ComboBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dataGridViewMateriel = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonDeleteMat = new System.Windows.Forms.Button();
            this.buttonModifMat = new System.Windows.Forms.Button();
            this.buttonAddMat = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.typesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOldInterv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNewInterv)).BeginInit();
            this.tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMateriel)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.utilisateurToolStripMenuItem,
            this.rafraîchirLaPageToolStripMenuItem,
            this.administrateurToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1142, 28);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip";
            // 
            // utilisateurToolStripMenuItem
            // 
            this.utilisateurToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.seDéconnecterToolStripMenuItem,
            this.quitterGMSYY2022ToolStripMenuItem});
            this.utilisateurToolStripMenuItem.Name = "utilisateurToolStripMenuItem";
            this.utilisateurToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.utilisateurToolStripMenuItem.Text = "GM-SYY2022";
            // 
            // seDéconnecterToolStripMenuItem
            // 
            this.seDéconnecterToolStripMenuItem.Name = "seDéconnecterToolStripMenuItem";
            this.seDéconnecterToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.seDéconnecterToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.seDéconnecterToolStripMenuItem.Text = "Se déconnecter";
            this.seDéconnecterToolStripMenuItem.Click += new System.EventHandler(this.seDéconnecterToolStripMenuItem_Click);
            // 
            // quitterGMSYY2022ToolStripMenuItem
            // 
            this.quitterGMSYY2022ToolStripMenuItem.Name = "quitterGMSYY2022ToolStripMenuItem";
            this.quitterGMSYY2022ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.quitterGMSYY2022ToolStripMenuItem.Size = new System.Drawing.Size(280, 26);
            this.quitterGMSYY2022ToolStripMenuItem.Text = "Quitter GM-SYY2022";
            this.quitterGMSYY2022ToolStripMenuItem.Click += new System.EventHandler(this.quitterGMSYY2022ToolStripMenuItem_Click);
            // 
            // rafraîchirLaPageToolStripMenuItem
            // 
            this.rafraîchirLaPageToolStripMenuItem.Name = "rafraîchirLaPageToolStripMenuItem";
            this.rafraîchirLaPageToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.rafraîchirLaPageToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.rafraîchirLaPageToolStripMenuItem.Text = "Rafraîchir";
            this.rafraîchirLaPageToolStripMenuItem.Click += new System.EventHandler(this.rafraîchirLaPageToolStripMenuItem_Click);
            // 
            // administrateurToolStripMenuItem
            // 
            this.administrateurToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.marquesToolStripMenuItem,
            this.utilisateursToolStripMenuItem,
            this.typesToolStripMenuItem});
            this.administrateurToolStripMenuItem.Name = "administrateurToolStripMenuItem";
            this.administrateurToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U)));
            this.administrateurToolStripMenuItem.Size = new System.Drawing.Size(121, 24);
            this.administrateurToolStripMenuItem.Text = "Administrateur";
            // 
            // marquesToolStripMenuItem
            // 
            this.marquesToolStripMenuItem.Name = "marquesToolStripMenuItem";
            this.marquesToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.M)));
            this.marquesToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.marquesToolStripMenuItem.Text = "Marques";
            this.marquesToolStripMenuItem.Click += new System.EventHandler(this.marquesToolStripMenuItem_Click);
            // 
            // utilisateursToolStripMenuItem
            // 
            this.utilisateursToolStripMenuItem.Name = "utilisateursToolStripMenuItem";
            this.utilisateursToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U)));
            this.utilisateursToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.utilisateursToolStripMenuItem.Text = "Utilisateurs";
            this.utilisateursToolStripMenuItem.Click += new System.EventHandler(this.utilisateursToolStripMenuItem_Click);
            // 
            // labelTechnicien
            // 
            this.labelTechnicien.AutoSize = true;
            this.labelTechnicien.Location = new System.Drawing.Point(2, 254);
            this.labelTechnicien.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTechnicien.Name = "labelTechnicien";
            this.labelTechnicien.Size = new System.Drawing.Size(153, 16);
            this.labelTechnicien.TabIndex = 1;
            this.labelTechnicien.Text = "Techniciens disponibles";
            // 
            // labelClient
            // 
            this.labelClient.AutoSize = true;
            this.labelClient.BackColor = System.Drawing.SystemColors.Control;
            this.labelClient.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelClient.Location = new System.Drawing.Point(2, 0);
            this.labelClient.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelClient.Name = "labelClient";
            this.labelClient.Size = new System.Drawing.Size(47, 16);
            this.labelClient.TabIndex = 5;
            this.labelClient.Text = "Clients";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelConnected,
            this.toolStripStatusLabelAdminMode,
            this.toolStripStatusLabelTimeRefresh,
            this.toolStripStatusLabelSelectedCell});
            this.statusStrip1.Location = new System.Drawing.Point(0, 753);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1142, 26);
            this.statusStrip1.TabIndex = 14;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabelConnected
            // 
            this.toolStripStatusLabelConnected.Name = "toolStripStatusLabelConnected";
            this.toolStripStatusLabelConnected.Size = new System.Drawing.Size(224, 20);
            this.toolStripStatusLabelConnected.Text = "toolStripStatusLabelIsConnected";
            // 
            // toolStripStatusLabelAdminMode
            // 
            this.toolStripStatusLabelAdminMode.Name = "toolStripStatusLabelAdminMode";
            this.toolStripStatusLabelAdminMode.Size = new System.Drawing.Size(226, 20);
            this.toolStripStatusLabelAdminMode.Text = "toolStripStatusLabelAdminMode";
            // 
            // toolStripStatusLabelTimeRefresh
            // 
            this.toolStripStatusLabelTimeRefresh.Name = "toolStripStatusLabelTimeRefresh";
            this.toolStripStatusLabelTimeRefresh.Size = new System.Drawing.Size(0, 20);
            // 
            // toolStripStatusLabelSelectedCell
            // 
            this.toolStripStatusLabelSelectedCell.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabelSelectedCell.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabelSelectedCell.Name = "toolStripStatusLabelSelectedCell";
            this.toolStripStatusLabelSelectedCell.Size = new System.Drawing.Size(0, 20);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.Controls.Add(this.buttonDelTech, 0, 9);
            this.tableLayoutPanel5.Controls.Add(this.buttonModifyTech, 0, 8);
            this.tableLayoutPanel5.Controls.Add(this.buttonAddTech, 0, 7);
            this.tableLayoutPanel5.Controls.Add(this.buttonDelClient, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.buttonModifyClient, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.buttonAddClient, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.listBoxClient, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.labelClient, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.listBoxTech, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.labelTechnicien, 0, 5);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(10, 31);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 10;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.Size = new System.Drawing.Size(168, 549);
            this.tableLayoutPanel5.TabIndex = 24;
            // 
            // buttonDelTech
            // 
            this.buttonDelTech.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDelTech.Location = new System.Drawing.Point(3, 515);
            this.buttonDelTech.Name = "buttonDelTech";
            this.buttonDelTech.Size = new System.Drawing.Size(165, 23);
            this.buttonDelTech.TabIndex = 32;
            this.buttonDelTech.Text = "SUPPRIMER";
            this.buttonDelTech.UseVisualStyleBackColor = true;
            this.buttonDelTech.Click += new System.EventHandler(this.buttonDelTech_Click);
            // 
            // buttonModifyTech
            // 
            this.buttonModifyTech.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonModifyTech.Location = new System.Drawing.Point(3, 488);
            this.buttonModifyTech.Name = "buttonModifyTech";
            this.buttonModifyTech.Size = new System.Drawing.Size(165, 21);
            this.buttonModifyTech.TabIndex = 32;
            this.buttonModifyTech.Text = "MODIFIER";
            this.buttonModifyTech.UseVisualStyleBackColor = true;
            this.buttonModifyTech.Click += new System.EventHandler(this.buttonModifyTech_Click);
            // 
            // buttonAddTech
            // 
            this.buttonAddTech.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonAddTech.Location = new System.Drawing.Point(3, 459);
            this.buttonAddTech.Name = "buttonAddTech";
            this.buttonAddTech.Size = new System.Drawing.Size(165, 23);
            this.buttonAddTech.TabIndex = 32;
            this.buttonAddTech.Text = "AJOUTER";
            this.buttonAddTech.UseVisualStyleBackColor = true;
            this.buttonAddTech.Click += new System.EventHandler(this.buttonAddTech_Click);
            // 
            // buttonDelClient
            // 
            this.buttonDelClient.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDelClient.Location = new System.Drawing.Point(3, 228);
            this.buttonDelClient.Name = "buttonDelClient";
            this.buttonDelClient.Size = new System.Drawing.Size(165, 23);
            this.buttonDelClient.TabIndex = 32;
            this.buttonDelClient.Text = "SUPPRIMER";
            this.buttonDelClient.UseVisualStyleBackColor = true;
            this.buttonDelClient.Click += new System.EventHandler(this.buttonDelClient_Click);
            // 
            // buttonModifyClient
            // 
            this.buttonModifyClient.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonModifyClient.Location = new System.Drawing.Point(3, 200);
            this.buttonModifyClient.Name = "buttonModifyClient";
            this.buttonModifyClient.Size = new System.Drawing.Size(165, 22);
            this.buttonModifyClient.TabIndex = 32;
            this.buttonModifyClient.Text = "MODIFIER";
            this.buttonModifyClient.UseVisualStyleBackColor = true;
            this.buttonModifyClient.Click += new System.EventHandler(this.buttonModifyClient_Click);
            // 
            // buttonAddClient
            // 
            this.buttonAddClient.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonAddClient.Location = new System.Drawing.Point(3, 171);
            this.buttonAddClient.Name = "buttonAddClient";
            this.buttonAddClient.Size = new System.Drawing.Size(165, 23);
            this.buttonAddClient.TabIndex = 32;
            this.buttonAddClient.Text = "AJOUTER";
            this.buttonAddClient.UseVisualStyleBackColor = true;
            this.buttonAddClient.Click += new System.EventHandler(this.buttonAddClient_Click);
            // 
            // listBoxClient
            // 
            this.listBoxClient.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxClient.FormattingEnabled = true;
            this.listBoxClient.ItemHeight = 16;
            this.listBoxClient.Location = new System.Drawing.Point(2, 18);
            this.listBoxClient.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxClient.Name = "listBoxClient";
            this.listBoxClient.Size = new System.Drawing.Size(166, 148);
            this.listBoxClient.TabIndex = 6;
            this.listBoxClient.SelectedIndexChanged += new System.EventHandler(this.listBoxClient_SelectedIndexChanged);
            // 
            // listBoxTech
            // 
            this.listBoxTech.FormattingEnabled = true;
            this.listBoxTech.ItemHeight = 16;
            this.listBoxTech.Location = new System.Drawing.Point(3, 273);
            this.listBoxTech.Name = "listBoxTech";
            this.listBoxTech.Size = new System.Drawing.Size(165, 180);
            this.listBoxTech.TabIndex = 7;
            this.listBoxTech.SelectedIndexChanged += new System.EventHandler(this.listBoxTech_SelectedIndexChanged);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 171F));
            this.tableLayoutPanel2.Controls.Add(this.buttonAddInterv, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.textBoxIntervCom, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.labelNewIntervCom, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonIntervModify, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.buttonDeleteInterv, 0, 4);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(245, 242);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.78832F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 83.21168F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(701, 238);
            this.tableLayoutPanel2.TabIndex = 30;
            // 
            // buttonAddInterv
            // 
            this.buttonAddInterv.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonAddInterv.Location = new System.Drawing.Point(3, 140);
            this.buttonAddInterv.Name = "buttonAddInterv";
            this.buttonAddInterv.Size = new System.Drawing.Size(695, 23);
            this.buttonAddInterv.TabIndex = 29;
            this.buttonAddInterv.Text = "AJOUTER";
            this.buttonAddInterv.UseVisualStyleBackColor = true;
            this.buttonAddInterv.Click += new System.EventHandler(this.buttonAddInterv_Click);
            // 
            // textBoxIntervCom
            // 
            this.textBoxIntervCom.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxIntervCom.Location = new System.Drawing.Point(3, 26);
            this.textBoxIntervCom.Multiline = true;
            this.textBoxIntervCom.Name = "textBoxIntervCom";
            this.textBoxIntervCom.Size = new System.Drawing.Size(695, 108);
            this.textBoxIntervCom.TabIndex = 28;
            // 
            // labelNewIntervCom
            // 
            this.labelNewIntervCom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelNewIntervCom.AutoSize = true;
            this.labelNewIntervCom.Location = new System.Drawing.Point(3, 0);
            this.labelNewIntervCom.Name = "labelNewIntervCom";
            this.labelNewIntervCom.Size = new System.Drawing.Size(695, 16);
            this.labelNewIntervCom.TabIndex = 28;
            this.labelNewIntervCom.Text = "Commentaire";
            // 
            // buttonIntervModify
            // 
            this.buttonIntervModify.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonIntervModify.Location = new System.Drawing.Point(3, 169);
            this.buttonIntervModify.Name = "buttonIntervModify";
            this.buttonIntervModify.Size = new System.Drawing.Size(695, 21);
            this.buttonIntervModify.TabIndex = 30;
            this.buttonIntervModify.Text = "MODIFIER";
            this.buttonIntervModify.UseVisualStyleBackColor = true;
            this.buttonIntervModify.Click += new System.EventHandler(this.buttonIntervModify_Click);
            // 
            // buttonDeleteInterv
            // 
            this.buttonDeleteInterv.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDeleteInterv.Location = new System.Drawing.Point(3, 196);
            this.buttonDeleteInterv.Name = "buttonDeleteInterv";
            this.buttonDeleteInterv.Size = new System.Drawing.Size(695, 23);
            this.buttonDeleteInterv.TabIndex = 31;
            this.buttonDeleteInterv.Text = "SUPPRIMER";
            this.buttonDeleteInterv.UseVisualStyleBackColor = true;
            this.buttonDeleteInterv.Click += new System.EventHandler(this.buttonDeleteInterv_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.dataGridViewOldInterv, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelIntervPrevues, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelOldInterv, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridViewNewInterv, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(14, 16);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90.90909F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(932, 206);
            this.tableLayoutPanel1.TabIndex = 29;
            // 
            // dataGridViewOldInterv
            // 
            this.dataGridViewOldInterv.AllowUserToAddRows = false;
            this.dataGridViewOldInterv.AllowUserToDeleteRows = false;
            this.dataGridViewOldInterv.AllowUserToResizeRows = false;
            this.dataGridViewOldInterv.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewOldInterv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewOldInterv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOldInterv.Location = new System.Drawing.Point(469, 21);
            this.dataGridViewOldInterv.Name = "dataGridViewOldInterv";
            this.dataGridViewOldInterv.RowHeadersVisible = false;
            this.dataGridViewOldInterv.RowHeadersWidth = 51;
            this.dataGridViewOldInterv.RowTemplate.Height = 24;
            this.dataGridViewOldInterv.Size = new System.Drawing.Size(460, 180);
            this.dataGridViewOldInterv.TabIndex = 26;
            this.dataGridViewOldInterv.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewOldInterv_CellMouseUp);
            // 
            // labelIntervPrevues
            // 
            this.labelIntervPrevues.AutoSize = true;
            this.labelIntervPrevues.Location = new System.Drawing.Point(2, 0);
            this.labelIntervPrevues.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelIntervPrevues.Name = "labelIntervPrevues";
            this.labelIntervPrevues.Size = new System.Drawing.Size(134, 16);
            this.labelIntervPrevues.TabIndex = 7;
            this.labelIntervPrevues.Text = "Interventions prévues";
            // 
            // labelOldInterv
            // 
            this.labelOldInterv.AutoSize = true;
            this.labelOldInterv.Location = new System.Drawing.Point(468, 0);
            this.labelOldInterv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelOldInterv.Name = "labelOldInterv";
            this.labelOldInterv.Size = new System.Drawing.Size(172, 16);
            this.labelOldInterv.TabIndex = 7;
            this.labelOldInterv.Text = "Historique des interventions";
            // 
            // dataGridViewNewInterv
            // 
            this.dataGridViewNewInterv.AllowUserToAddRows = false;
            this.dataGridViewNewInterv.AllowUserToDeleteRows = false;
            this.dataGridViewNewInterv.AllowUserToResizeRows = false;
            this.dataGridViewNewInterv.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewNewInterv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewNewInterv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewNewInterv.Location = new System.Drawing.Point(3, 21);
            this.dataGridViewNewInterv.Name = "dataGridViewNewInterv";
            this.dataGridViewNewInterv.RowHeadersVisible = false;
            this.dataGridViewNewInterv.RowHeadersWidth = 51;
            this.dataGridViewNewInterv.RowTemplate.Height = 24;
            this.dataGridViewNewInterv.Size = new System.Drawing.Size(460, 180);
            this.dataGridViewNewInterv.TabIndex = 26;
            this.dataGridViewNewInterv.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewNewInterv_CellMouseUp);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.labelIntervDate, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.labelIntervTech, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.labelIntervMat, 0, 4);
            this.tableLayoutPanel7.Controls.Add(this.dateTimePickerInterv, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.comboBoxIntervTech, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.comboBoxIntervMat, 0, 5);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(14, 242);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 6;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 42.62295F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 57.37705F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 19F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(225, 163);
            this.tableLayoutPanel7.TabIndex = 31;
            // 
            // labelIntervDate
            // 
            this.labelIntervDate.AutoSize = true;
            this.labelIntervDate.Location = new System.Drawing.Point(3, 0);
            this.labelIntervDate.Name = "labelIntervDate";
            this.labelIntervDate.Size = new System.Drawing.Size(36, 16);
            this.labelIntervDate.TabIndex = 0;
            this.labelIntervDate.Text = "Date";
            // 
            // labelIntervTech
            // 
            this.labelIntervTech.AutoSize = true;
            this.labelIntervTech.Location = new System.Drawing.Point(3, 61);
            this.labelIntervTech.Name = "labelIntervTech";
            this.labelIntervTech.Size = new System.Drawing.Size(73, 16);
            this.labelIntervTech.TabIndex = 1;
            this.labelIntervTech.Text = "Technicien";
            // 
            // labelIntervMat
            // 
            this.labelIntervMat.AutoSize = true;
            this.labelIntervMat.Location = new System.Drawing.Point(3, 114);
            this.labelIntervMat.Name = "labelIntervMat";
            this.labelIntervMat.Size = new System.Drawing.Size(55, 16);
            this.labelIntervMat.TabIndex = 2;
            this.labelIntervMat.Text = "Matériel\r\n";
            // 
            // dateTimePickerInterv
            // 
            this.dateTimePickerInterv.Location = new System.Drawing.Point(3, 29);
            this.dateTimePickerInterv.Name = "dateTimePickerInterv";
            this.dateTimePickerInterv.Size = new System.Drawing.Size(219, 22);
            this.dateTimePickerInterv.TabIndex = 3;
            // 
            // comboBoxIntervTech
            // 
            this.comboBoxIntervTech.FormattingEnabled = true;
            this.comboBoxIntervTech.Location = new System.Drawing.Point(3, 83);
            this.comboBoxIntervTech.Name = "comboBoxIntervTech";
            this.comboBoxIntervTech.Size = new System.Drawing.Size(219, 24);
            this.comboBoxIntervTech.TabIndex = 4;
            this.comboBoxIntervTech.SelectedIndexChanged += new System.EventHandler(this.comboBoxIntervTech_SelectedIndexChanged);
            // 
            // comboBoxIntervMat
            // 
            this.comboBoxIntervMat.FormattingEnabled = true;
            this.comboBoxIntervMat.Location = new System.Drawing.Point(3, 134);
            this.comboBoxIntervMat.Name = "comboBoxIntervMat";
            this.comboBoxIntervMat.Size = new System.Drawing.Size(219, 24);
            this.comboBoxIntervMat.TabIndex = 5;
            this.comboBoxIntervMat.SelectedIndexChanged += new System.EventHandler(this.comboBoxIntervMat_SelectedIndexChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // dataGridViewMateriel
            // 
            this.dataGridViewMateriel.AllowUserToAddRows = false;
            this.dataGridViewMateriel.AllowUserToDeleteRows = false;
            this.dataGridViewMateriel.AllowUserToResizeRows = false;
            this.dataGridViewMateriel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewMateriel.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewMateriel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMateriel.Location = new System.Drawing.Point(8, 16);
            this.dataGridViewMateriel.Name = "dataGridViewMateriel";
            this.dataGridViewMateriel.RowHeadersVisible = false;
            this.dataGridViewMateriel.RowHeadersWidth = 51;
            this.dataGridViewMateriel.RowTemplate.Height = 24;
            this.dataGridViewMateriel.Size = new System.Drawing.Size(970, 136);
            this.dataGridViewMateriel.TabIndex = 18;
            this.dataGridViewMateriel.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewMateriel_CellFormatting);
            this.dataGridViewMateriel.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewMateriel_CellMouseUp);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.buttonDeleteMat, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.buttonModifMat, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.buttonAddMat, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(983, 16);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(146, 136);
            this.tableLayoutPanel3.TabIndex = 21;
            // 
            // buttonDeleteMat
            // 
            this.buttonDeleteMat.BackColor = System.Drawing.Color.DarkRed;
            this.buttonDeleteMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDeleteMat.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteMat.Location = new System.Drawing.Point(3, 93);
            this.buttonDeleteMat.Name = "buttonDeleteMat";
            this.buttonDeleteMat.Size = new System.Drawing.Size(140, 40);
            this.buttonDeleteMat.TabIndex = 2;
            this.buttonDeleteMat.Text = "SUPPRIMER";
            this.buttonDeleteMat.UseVisualStyleBackColor = false;
            this.buttonDeleteMat.Click += new System.EventHandler(this.buttonDeleteMat_Click);
            // 
            // buttonModifMat
            // 
            this.buttonModifMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonModifMat.Location = new System.Drawing.Point(3, 48);
            this.buttonModifMat.Name = "buttonModifMat";
            this.buttonModifMat.Size = new System.Drawing.Size(140, 39);
            this.buttonModifMat.TabIndex = 1;
            this.buttonModifMat.Text = "MODIFIER";
            this.buttonModifMat.UseVisualStyleBackColor = true;
            this.buttonModifMat.Click += new System.EventHandler(this.buttonModifMat_Click);
            // 
            // buttonAddMat
            // 
            this.buttonAddMat.BackColor = System.Drawing.Color.Gold;
            this.buttonAddMat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddMat.Location = new System.Drawing.Point(3, 3);
            this.buttonAddMat.Name = "buttonAddMat";
            this.buttonAddMat.Size = new System.Drawing.Size(140, 39);
            this.buttonAddMat.TabIndex = 0;
            this.buttonAddMat.Text = "AJOUTER";
            this.buttonAddMat.UseVisualStyleBackColor = false;
            this.buttonAddMat.Click += new System.EventHandler(this.buttonAddMat_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.tableLayoutPanel3);
            this.panel1.Controls.Add(this.dataGridViewMateriel);
            this.panel1.Location = new System.Drawing.Point(1, 586);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1141, 164);
            this.panel1.TabIndex = 32;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.Controls.Add(this.tableLayoutPanel7);
            this.panel2.Controls.Add(this.tableLayoutPanel2);
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Location = new System.Drawing.Point(184, 31);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(957, 549);
            this.panel2.TabIndex = 33;
            // 
            // typesToolStripMenuItem
            // 
            this.typesToolStripMenuItem.Name = "typesToolStripMenuItem";
            this.typesToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.typesToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.typesToolStripMenuItem.Text = "Types";
            this.typesToolStripMenuItem.Click += new System.EventHandler(this.typesToolStripMenuItem_Click);
            // 
            // FormMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1142, 779);
            this.Controls.Add(this.tableLayoutPanel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(1160, 826);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GM-SYY2022";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOldInterv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNewInterv)).EndInit();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMateriel)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem utilisateurToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seDéconnecterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitterGMSYY2022ToolStripMenuItem;
        private System.Windows.Forms.Label labelTechnicien;
        private System.Windows.Forms.Label labelClient;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelConnected;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.ToolStripMenuItem rafraîchirLaPageToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelTimeRefresh;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelSelectedCell;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button buttonAddInterv;
        private System.Windows.Forms.TextBox textBoxIntervCom;
        private System.Windows.Forms.Label labelNewIntervCom;
        private System.Windows.Forms.Button buttonIntervModify;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView dataGridViewNewInterv;
        private System.Windows.Forms.Label labelIntervPrevues;
        private System.Windows.Forms.DataGridView dataGridViewOldInterv;
        private System.Windows.Forms.Label labelOldInterv;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label labelIntervDate;
        private System.Windows.Forms.Label labelIntervTech;
        private System.Windows.Forms.Label labelIntervMat;
        private System.Windows.Forms.DateTimePicker dateTimePickerInterv;
        private System.Windows.Forms.ComboBox comboBoxIntervTech;
        private System.Windows.Forms.ComboBox comboBoxIntervMat;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.DataGridView dataGridViewMateriel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button buttonModifMat;
        private System.Windows.Forms.Button buttonAddMat;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonDeleteMat;
        private System.Windows.Forms.Button buttonDelTech;
        private System.Windows.Forms.Button buttonModifyTech;
        private System.Windows.Forms.Button buttonAddTech;
        private System.Windows.Forms.Button buttonDelClient;
        private System.Windows.Forms.Button buttonModifyClient;
        private System.Windows.Forms.Button buttonAddClient;
        private System.Windows.Forms.ListBox listBoxTech;
        private System.Windows.Forms.Button buttonDeleteInterv;
        private System.Windows.Forms.ListBox listBoxClient;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelAdminMode;
        private System.Windows.Forms.ToolStripMenuItem administrateurToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marquesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem utilisateursToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem typesToolStripMenuItem;
    }
}

