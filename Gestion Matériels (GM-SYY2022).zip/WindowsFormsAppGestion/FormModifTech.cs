﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class FormModifTech : Form
    {
        public string newNom;
        public FormModifTech()
        {
            InitializeComponent();
        }

        private void FormModifTech_Load(object sender, EventArgs e)
        {
            textBoxModifTech.Text = FormMain.selectedTechNom;
        }

        private void buttonModifTech_Click(object sender, EventArgs e)
        {
            this.newNom = textBoxModifTech.Text;
        }
    }
}
