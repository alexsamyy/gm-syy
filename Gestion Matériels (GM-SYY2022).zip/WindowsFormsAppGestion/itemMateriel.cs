﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppGestion
{
    internal class itemMateriel
    {
        public int id;
        public string nom, nSerie, dateTimeMTBF;
        public int clientIndex, typeIndex, marqueIndex;
        public DateTime dateTimeInstall;

        public itemMateriel(int id, string nom, string nSerie, string dateTimeMTBF, int clientIndex, int typeIndex, int marqueIndex, DateTime dateTimeInstall)
        {
            this.id = id;
            this.nom = nom;
            this.nSerie = nSerie;
            this.dateTimeMTBF = dateTimeMTBF;
            this.clientIndex = clientIndex;
            this.typeIndex = typeIndex;
            this.marqueIndex = marqueIndex;
            this.dateTimeInstall = dateTimeInstall;
        }

        public override string ToString()
        {
            return this.nSerie;
        }
    }
}
