﻿namespace WindowsFormsAppGestion
{
    partial class FormModifTech
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxModifTech = new System.Windows.Forms.TextBox();
            this.labelModifTech = new System.Windows.Forms.Label();
            this.labelTitleAddTech = new System.Windows.Forms.Label();
            this.buttonCancelTech = new System.Windows.Forms.Button();
            this.buttonModifTech = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxModifTech
            // 
            this.textBoxModifTech.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxModifTech.Location = new System.Drawing.Point(13, 78);
            this.textBoxModifTech.Name = "textBoxModifTech";
            this.textBoxModifTech.Size = new System.Drawing.Size(392, 27);
            this.textBoxModifTech.TabIndex = 9;
            // 
            // labelModifTech
            // 
            this.labelModifTech.AutoSize = true;
            this.labelModifTech.Location = new System.Drawing.Point(12, 59);
            this.labelModifTech.Name = "labelModifTech";
            this.labelModifTech.Size = new System.Drawing.Size(39, 16);
            this.labelModifTech.TabIndex = 8;
            this.labelModifTech.Text = "Nom ";
            // 
            // labelTitleAddTech
            // 
            this.labelTitleAddTech.AutoSize = true;
            this.labelTitleAddTech.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleAddTech.Location = new System.Drawing.Point(96, 11);
            this.labelTitleAddTech.Name = "labelTitleAddTech";
            this.labelTitleAddTech.Size = new System.Drawing.Size(223, 25);
            this.labelTitleAddTech.TabIndex = 7;
            this.labelTitleAddTech.Text = "Modifier un technicien";
            // 
            // buttonCancelTech
            // 
            this.buttonCancelTech.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancelTech.Location = new System.Drawing.Point(330, 159);
            this.buttonCancelTech.Name = "buttonCancelTech";
            this.buttonCancelTech.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelTech.TabIndex = 6;
            this.buttonCancelTech.Text = "Annuler";
            this.buttonCancelTech.UseVisualStyleBackColor = true;
            // 
            // buttonModifTech
            // 
            this.buttonModifTech.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonModifTech.Location = new System.Drawing.Point(249, 159);
            this.buttonModifTech.Name = "buttonModifTech";
            this.buttonModifTech.Size = new System.Drawing.Size(75, 23);
            this.buttonModifTech.TabIndex = 5;
            this.buttonModifTech.Text = "Valider";
            this.buttonModifTech.UseVisualStyleBackColor = true;
            this.buttonModifTech.Click += new System.EventHandler(this.buttonModifTech_Click);
            // 
            // FormModifTech
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 192);
            this.Controls.Add(this.textBoxModifTech);
            this.Controls.Add(this.labelModifTech);
            this.Controls.Add(this.labelTitleAddTech);
            this.Controls.Add(this.buttonCancelTech);
            this.Controls.Add(this.buttonModifTech);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormModifTech";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Modifier un technicien";
            this.Load += new System.EventHandler(this.FormModifTech_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxModifTech;
        private System.Windows.Forms.Label labelModifTech;
        private System.Windows.Forms.Label labelTitleAddTech;
        private System.Windows.Forms.Button buttonCancelTech;
        private System.Windows.Forms.Button buttonModifTech;
    }
}