﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class FormAddClient : Form
    {
        helper helper = new helper();
        public FormAddClient()
        {
            InitializeComponent();
        }

        private void buttonAddClient_Click(object sender, EventArgs e)
        {
            helper.query
                ("INSERT INTO CLIENT(NOM, NUM_CLIENT, ADRESSE, MAIL, TELEPHONE)" +
                " VALUES('" +
                textBoxNomClient.Text + "','" +
                textBoxNumClient.Text + "','" +
                textBoxAdresseClient.Text + "','" +
                textBoxMailClient.Text + "','" +
                textBoxTelClient.Text + "');");
        }
    }
}
