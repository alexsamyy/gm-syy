﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class FormMarque : Form
    {
        private bool addBrand;
        private helper helper = new helper();
        public string nom;
        public FormMarque()
        {

        }
        public FormMarque(string use)
        {
            InitializeComponent();
            if (use == "add")
            {
                addBrand = true;
            }
            else
            {
                if (use == "update")
                {
                    addBrand = false;
                }
                else
                {
                    return;
                }
            }
        }

        private void FormMarque_Load(object sender, EventArgs e)
        {
            if (addBrand == false)
            {
                textBoxMarqueNom.Text = FormAdmin.nom;
            }
        }

        private void buttonMarqueOK_Click(object sender, EventArgs e)
        {
            this.nom = textBoxMarqueNom.Text;
        }
    }
}
