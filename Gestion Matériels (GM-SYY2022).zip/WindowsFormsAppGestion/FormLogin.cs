﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class FormLogin : SessionInfo
    {
        public bool IsConnected = false;
        public bool adminMode = false;
        private helper helper = new helper();
        private ClassHash hash = new ClassHash();
        public FormLogin()
        {
            InitializeComponent();
        }
        private void buttonConnection_Click(object sender, EventArgs e)
        {
            SqlConnection cn = null;
            SqlCommand com = null;
            SqlDataReader rd = null;
            
            try
            {
                SHA256 sha256Hash = SHA256.Create();

                string strcn = "Server = .\\SQLEXPRESS; Database = Gestion_mat; Trusted_Connection = True";
                cn = new SqlConnection(strcn);
                cn.Open();
                string strsql = "SELECT * FROM ADMINISTRATEUR WHERE ADMINISTRATEUR.LOGIN ='" + textBoxLogin.Text + "';";

                com = new SqlCommand(strsql, cn);
                rd = com.ExecuteReader();

                if (rd.Read())
                {
                    if (textBoxLogin.Text == "admin")
                    {
                        if (hash.verifyHash(sha256Hash, textBoxMDP.Text, rd["MDP"].ToString()))
                        {
                            this.InitSession(textBoxLogin.Text, textBoxMDP.Text);
                            IsConnected = true;
                            adminMode = true;

                            this.DialogResult = DialogResult.OK;
                        }
                        else
                        {
                            MessageBox.Show("Erreur de connexion !");
                            this.DialogResult = DialogResult.None;
                        }
                    }
                    else
                    {
                        if (hash.verifyHash(sha256Hash, textBoxMDP.Text, rd["MDP"].ToString()))
                        {
                            this.InitSession(textBoxLogin.Text, textBoxMDP.Text);
                            IsConnected = true;

                            this.DialogResult = DialogResult.OK;
                        }
                        else
                        {
                            MessageBox.Show("Erreur de connexion !");
                            this.DialogResult = DialogResult.None;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Erreur de connexion !");
                    this.DialogResult = DialogResult.None;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Erreur de connexion");
                this.DialogResult = DialogResult.None;
            }
            finally
            {
                com.Dispose();
                cn.Dispose();
            }
        }
    }
}
