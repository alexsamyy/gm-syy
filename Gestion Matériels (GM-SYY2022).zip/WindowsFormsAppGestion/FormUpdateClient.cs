﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class FormUpdateClient : Form
    {
        public string newNom, newNClient, newAdresse, newMail, newTel;

        private void buttonUpdateClient_Click(object sender, EventArgs e)
        {
            this.newNom = textBoxNomClient.Text;
            this.newNClient = textBoxNumClient.Text;
            this.newAdresse = textBoxAdresseClient.Text;
            this.newMail = textBoxMailClient.Text;
            this.newTel = textBoxTelClient.Text;
        }

        public FormUpdateClient()
        {
            InitializeComponent();
        }

        private void FormUpdateClient_Load(object sender, EventArgs e)
        {
            textBoxNomClient.Text = FormMain.selectedClientNom;
            textBoxNumClient.Text = FormMain.selectedN_client;
            textBoxAdresseClient.Text = FormMain.selectedAdresse;
            textBoxMailClient.Text = FormMain.selectedMail;
            textBoxTelClient.Text = FormMain.selectedTel;
        }
    }
}
