﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public class SessionInfo : Form
    {
        public string ID;
        public string pwd;

        public void InitSession(string id, string pwd)
        {
            this.ID = id;
            this.pwd = pwd;
        }
    }
}
