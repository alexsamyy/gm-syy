﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class FormType : Form
    {
        private SqlCommand cmd;
        public FormType()
        {
            InitializeComponent();
        }
        private void FormType_Load(object sender, EventArgs e)
        {
            // --------------------- UTILISATION PROCEDURE STOCKEE "AffType" ----------------------

            SqlConnection conn =
            new SqlConnection("Server = .\\SQLEXPRESS; Database = Gestion_mat; Trusted_Connection = True");

            conn.Open();

            cmd = new SqlCommand("AffType", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                listBoxType.Items.Add(dr["NOM".ToString()]);
            }
        }
    }
}
