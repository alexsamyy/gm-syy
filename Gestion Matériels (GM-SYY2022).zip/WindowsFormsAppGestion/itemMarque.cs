﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppGestion
{
    internal class itemMarque
    {
        public int ID;
        public string nom;

        public itemMarque(int id, string nom)
        {
            this.ID = id;
            this.nom = nom;
        }

        public override string ToString()
        {
            return this.nom;
        }
    }
}
