﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppGestion
{
    internal class itemClient
    {
        public int ID;
        public string nom, n_client, adresse, mail, telephone;

        public itemClient(int id, string nom, string n_client, string adresse, string mail, string telephone)
        {
            this.ID = id;
            this.nom = nom;
            this.n_client = n_client;
            this.adresse = adresse;
            this.mail = mail;
            this.telephone = telephone;
        }

        public override string ToString()
        {
            return this.nom;
        }
    }
}
