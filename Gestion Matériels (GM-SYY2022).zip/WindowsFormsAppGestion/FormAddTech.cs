﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class FormAddTech : Form
    {
        public FormAddTech()
        {
            InitializeComponent();
        }

        private void buttonAddTech_Click(object sender, EventArgs e)
        {
            if (textBoxAddTech.Text.Length <= 2)
            {
                MessageBox.Show("Veuillez saisir un autre nom");
            }
            else
            {
                string strcn = "Server = .\\SQLEXPRESS; Database = Gestion_mat; Trusted_Connection = True";
                SqlConnection c = new SqlConnection(strcn);
                c.Open();

                SqlCommand addTech = new SqlCommand("INSERT INTO TECHNICIEN(NOM) VALUES('" + textBoxAddTech.Text + "');", c);
                addTech.ExecuteNonQuery();
            }
        }
    }
}
