﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    internal class helper
    {
        public SqlConnection conn =
            new SqlConnection("Server = .\\SQLEXPRESS; Database = Gestion_mat; Trusted_Connection = True");
        public void query(string rq)
        {
            try
            {
                conn.Open();

                SqlCommand sqlCommand = new SqlCommand(rq, conn);

                sqlCommand.ExecuteNonQuery();

                conn.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public SqlDataReader selectQuery(string rq)
        {
            conn.Open();

            SqlCommand select = new SqlCommand(rq, conn);
            SqlDataReader drSelect = select.ExecuteReader();

            return drSelect;
        }
    }
}
