﻿namespace WindowsFormsAppGestion
{
    partial class FormMarque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxMarqueNom = new System.Windows.Forms.TextBox();
            this.labelMarque = new System.Windows.Forms.Label();
            this.labelTitleMarque = new System.Windows.Forms.Label();
            this.buttonMarqueCancel = new System.Windows.Forms.Button();
            this.buttonMarqueOK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxMarqueNom
            // 
            this.textBoxMarqueNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMarqueNom.Location = new System.Drawing.Point(34, 105);
            this.textBoxMarqueNom.Name = "textBoxMarqueNom";
            this.textBoxMarqueNom.Size = new System.Drawing.Size(392, 27);
            this.textBoxMarqueNom.TabIndex = 14;
            // 
            // labelMarque
            // 
            this.labelMarque.AutoSize = true;
            this.labelMarque.Location = new System.Drawing.Point(33, 86);
            this.labelMarque.Name = "labelMarque";
            this.labelMarque.Size = new System.Drawing.Size(36, 16);
            this.labelMarque.TabIndex = 13;
            this.labelMarque.Text = "Nom";
            // 
            // labelTitleMarque
            // 
            this.labelTitleMarque.AutoSize = true;
            this.labelTitleMarque.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleMarque.Location = new System.Drawing.Point(98, 36);
            this.labelTitleMarque.Name = "labelTitleMarque";
            this.labelTitleMarque.Size = new System.Drawing.Size(238, 25);
            this.labelTitleMarque.TabIndex = 12;
            this.labelTitleMarque.Text = "Paramétrer une marque";
            // 
            // buttonMarqueCancel
            // 
            this.buttonMarqueCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonMarqueCancel.Location = new System.Drawing.Point(351, 186);
            this.buttonMarqueCancel.Name = "buttonMarqueCancel";
            this.buttonMarqueCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonMarqueCancel.TabIndex = 11;
            this.buttonMarqueCancel.Text = "Annuler";
            this.buttonMarqueCancel.UseVisualStyleBackColor = true;
            // 
            // buttonMarqueOK
            // 
            this.buttonMarqueOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonMarqueOK.Location = new System.Drawing.Point(270, 186);
            this.buttonMarqueOK.Name = "buttonMarqueOK";
            this.buttonMarqueOK.Size = new System.Drawing.Size(75, 23);
            this.buttonMarqueOK.TabIndex = 10;
            this.buttonMarqueOK.Text = "Valider";
            this.buttonMarqueOK.UseVisualStyleBackColor = true;
            this.buttonMarqueOK.Click += new System.EventHandler(this.buttonMarqueOK_Click);
            // 
            // FormMarque
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 247);
            this.Controls.Add(this.textBoxMarqueNom);
            this.Controls.Add(this.labelMarque);
            this.Controls.Add(this.labelTitleMarque);
            this.Controls.Add(this.buttonMarqueCancel);
            this.Controls.Add(this.buttonMarqueOK);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormMarque";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Administrateur";
            this.Load += new System.EventHandler(this.FormMarque_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxMarqueNom;
        private System.Windows.Forms.Label labelMarque;
        private System.Windows.Forms.Label labelTitleMarque;
        private System.Windows.Forms.Button buttonMarqueCancel;
        private System.Windows.Forms.Button buttonMarqueOK;
    }
}