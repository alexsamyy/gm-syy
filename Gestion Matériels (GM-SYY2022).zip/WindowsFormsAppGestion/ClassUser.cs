﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppGestion
{
    internal class ClassUser
    {
        public int id;
        public string login, mdp;
        private helper helper = new helper();
        public ClassUser(int id, string login, string mdp)
        {
            this.id = id;
            this.login = login;
            this.mdp = mdp;
        }

        public void addNewUser(string login, string mdp)
        {
            helper.query("INSERT INTO ADMINISTRATEUR(LOGIN, MDP)" +
                    " VALUES('" + login + "','" + mdp + "');");
        }
    }
}
