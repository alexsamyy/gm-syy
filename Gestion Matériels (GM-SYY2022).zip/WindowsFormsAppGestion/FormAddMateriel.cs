﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppGestion
{
    public partial class labelMateriel : Form
    {
        public string nom, nSerie, dateTimeMTBF;
        public int clientIndex, typeIndex, marqueIndex;
        public DateTime dateTimeInstall;

        private void buttonAddMateriel_Click(object sender, EventArgs e)
        {
            this.nom = textBoxNom.Text;
            this.nSerie = textBoxNserie.Text;
            this.dateTimeInstall = dateTimePickerInstall.Value;
            this.dateTimeMTBF = numericUpDownMTBF.Value.ToString();

            try
            {
                itemTech client = (itemTech)comboBoxClient.SelectedItem;
                this.clientIndex = client.ID;
            }
            catch
            {
                return;
            }

            try
            {
            itemType type = (itemType)comboBoxType.SelectedItem;
            this.typeIndex = type.ID;
            }
            catch
            {
                return;
            }

            try
            {
            itemMarque marque = (itemMarque)comboBoxMarque.SelectedItem;
            this.marqueIndex = marque.ID;
            }
            catch
            {
                return;
            }
        }
        private void labelMateriel_Load(object sender, EventArgs e)
        {
            string strcn = "Server = .\\SQLEXPRESS; Database = Gestion_mat; Trusted_Connection = True";
            SqlConnection c = new SqlConnection(strcn);
            c.Open();

            // ============= COMBOBOX-MARQUE ===============
            SqlCommand selectMarque = new SqlCommand("SELECT * FROM MARQUE", c);
            SqlDataReader drMarque = selectMarque.ExecuteReader();

            comboBoxMarque.SelectedIndex = 0;

            dateTimePickerInstall.MaxDate = DateTime.Now;

            while (drMarque.Read())
            {
                int id = Convert.ToInt32(drMarque["ID_MARQUE"]);
                string nom = drMarque["NOM"].ToString();

                itemMarque im = new itemMarque(id, nom);

                comboBoxMarque.Items.Add(im);
            }

            drMarque.Close();


            // ============= COMBOBOX-CLIENT ===============
            SqlCommand selectClient = new SqlCommand("SELECT * FROM CLIENT", c);
            SqlDataReader dr = selectClient.ExecuteReader();

            comboBoxClient.SelectedIndex = 0;

            while (dr.Read())
            {
                int id = Convert.ToInt32(dr["ID_CLIENT"]);
                string nom = dr["NOM"].ToString();

                itemTech ic = new itemTech(id, nom);

                comboBoxClient.Items.Add(ic);
            }

            dr.Close();


            // ============== COMBOBOX-TYPE =================
            SqlCommand selectType = new SqlCommand("SELECT * FROM TYPE", c);
            SqlDataReader drType = selectType.ExecuteReader();

            comboBoxType.SelectedIndex = 0;

            while (drType.Read())
            {
                int id = Convert.ToInt32(drType["ID_TYPE"]);
                string nom = drType["NOM"].ToString();

                itemType it = new itemType(id, nom);

                comboBoxType.Items.Add(it);
            }

            drType.Close();
        }

        public labelMateriel()
        {
            InitializeComponent();
        }
    }
}