﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace WindowsFormsAppGestion
{
    public partial class FormMain : SessionInfo
    {
        private helper helper = new helper();
        public bool IsConnected;
        
        public FormMain()
        {
            InitializeComponent();
        }

        // -----------------------------------------------
        // ------------------- METHODES ------------------
        // -----------------------------------------------

        private void loadLogin()
        {
            FormLogin connection = new FormLogin();
            DialogResult dresult = connection.ShowDialog();
            if (dresult == DialogResult.OK)
            {
                if (connection.adminMode == true)
                {
                    toolStripStatusLabelAdminMode.Text = "Mode administrateur";
                }
                else
                {
                    toolStripStatusLabelAdminMode.Text = "";
                    administrateurToolStripMenuItem.Visible = false;
                }

                this.IsConnected = connection.IsConnected;

                toolStripStatusLabelConnected.Text = "Connected";
                
                return;
            }
            else
            {
                Application.Exit();
            }
        }

        // ------------------------------------FILL MATERIEL GRIDVIEW----------------------------------
        private void fillGridViewMat()
        {
            SqlDataReader reader = helper.selectQuery(
                "SELECT m.ID_MATERIEL, m.NOM, m.N_SERIE, m.DATE_INSTALL, m.MTBF, c.NOM as CLIENT, t.NOM as TYPE, marque.NOM as MARQUE," +
                " m.ID_CLIENT, m.ID_TYPE, m.ID_MARQUE" +
                " FROM MATERIEL m JOIN CLIENT c on m.ID_CLIENT = c.ID_CLIENT JOIN MARQUE marque on m.ID_MARQUE = marque.ID_MARQUE" +
                " JOIN TYPE t on m.ID_TYPE = t.ID_TYPE ORDER BY MTBF ASC");
            
            var ds = new DataTable();
            ds.Load(reader);
            dataGridViewMateriel.ReadOnly = true;
            dataGridViewMateriel.DataSource = ds;
            dataGridViewMateriel.ClearSelection();

            dataGridViewMateriel.Columns[8].Visible = false;
            dataGridViewMateriel.Columns[9].Visible = false;
            dataGridViewMateriel.Columns[10].Visible = false;

            helper.conn.Close();
        }

        private void dataGridViewMateriel_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            foreach (DataGridViewRow row in dataGridViewMateriel.Rows)
                if (Convert.ToInt32(row.Cells[4].Value) < 3)
                {
                    row.DefaultCellStyle.BackColor = Color.Red;
                    row.DefaultCellStyle.ForeColor = Color.White;
                }
        }

        //------------------------------------FILL MATERIEL COMBOBOX-----------------------------------
        private void fillComboBoxMat()
        {
            SqlDataReader readerMat = helper.selectQuery("SELECT * FROM MATERIEL");

            while (readerMat.Read())
            {
                int id = Convert.ToInt32(readerMat["ID_MATERIEL"]);
                string nom = readerMat["NOM"].ToString();
                string n_serie = readerMat["N_SERIE"].ToString();
                DateTime dateMat = (DateTime)readerMat["DATE_INSTALL"];
                string MTBF = readerMat["MTBF"].ToString();
                int marqueIndex = Convert.ToInt32(readerMat["ID_MARQUE"]);
                int typeIndex = Convert.ToInt32(readerMat["ID_TYPE"]);
                int clientIndex = Convert.ToInt32(readerMat["ID_CLIENT"]);

                itemMateriel im = new itemMateriel(id, nom, n_serie, MTBF, clientIndex, typeIndex, marqueIndex, dateMat);

                comboBoxIntervMat.Items.Add(im);
            }

            helper.conn.Close();
        }

        // ------------------------------------FILL CLIENT LISTBOX-------------------------------------
        private void fillListBoxClient()
        {
            SqlDataReader dr = helper.selectQuery("SELECT * FROM CLIENT");

            while (dr.Read())
            {
                //FILL TECHNICIEN COMBOBOX
                int id = Convert.ToInt32(dr["ID_CLIENT"]);
                string nom = dr["NOM"].ToString();
                string n_client = dr["NUM_CLIENT"].ToString();
                string adresse = dr["ADRESSE"].ToString();
                string mail = dr["MAIL"].ToString();
                string tel = dr["TELEPHONE"].ToString();

                itemClient ic = new itemClient(id, nom, n_client, adresse, mail, tel);

                listBoxClient.Items.Add(ic);
            }

            helper.conn.Close();
        }

        //------------------------------------FILL TECHNICIEN LISTBOX----------------------------------
        private void fillListBoxTech()
        {
            SqlDataReader drtech = helper.selectQuery("SELECT * FROM TECHNICIEN");

            while (drtech.Read())
            {
                //FILL TECHNICIEN COMBOBOX
                int id = Convert.ToInt32(drtech["ID_TECHNICIEN"]);
                string nom = drtech["NOM"].ToString();

                itemTech it = new itemTech(id, nom);

                listBoxTech.Items.Add(it);
                comboBoxIntervTech.Items.Add(it);
            }

            helper.conn.Close();
        }

        //----------------------------FILL INTERVENTIONS PREVUES---------------------------------------
        private void fillDataGridIntervPrevue()
        {
            SqlDataReader drNewInterv =
                helper.selectQuery
                ("SELECT i.ID_INTERVENTION, i.DATE, i.COMMENTAIRE, i.ID_TECHNICIEN, i.ID_MATERIEL, t.NOM" +
                " as TECHNICIEN FROM INTERVENTION i JOIN TECHNICIEN t on i.ID_TECHNICIEN = t.ID_TECHNICIEN" +
                " WHERE DATE >= GETDATE()");

            var dtNewInterv = new DataTable();
            dtNewInterv.Load(drNewInterv);
            dataGridViewNewInterv.DataSource = dtNewInterv;

            helper.conn.Close();

            dataGridViewNewInterv.ClearSelection();

            dataGridViewNewInterv.Columns[3].Visible = false;
        }

        //-----------------------------FILL INTERVENTIONS PASSEES---------------------------------------
        private void fillDataGridIntervPassee()
        {
            SqlDataReader drOldInterv = 
                helper.selectQuery("SELECT i.ID_INTERVENTION, i.DATE, i.COMMENTAIRE, i.ID_TECHNICIEN, i.ID_MATERIEL, " +
                "t.NOM as TECHNICIEN FROM INTERVENTION i JOIN TECHNICIEN t on i.ID_TECHNICIEN = t.ID_TECHNICIEN WHERE DATE < GETDATE()");

            var dtOldInterv = new DataTable();
            dtOldInterv.Load(drOldInterv);
            dataGridViewOldInterv.DataSource = dtOldInterv;

            helper.conn.Close();

            dataGridViewOldInterv.ClearSelection();
            dataGridViewOldInterv.Columns[3].Visible = false;
        }

        // -----------------------------------------------------------------------------------
        // ---------------------------------------FORM MAIN LOAD----------------------------------------
        // -----------------------------------------------------------------------------------
        private void FormMain_Load(object sender, EventArgs e)
        {
            buttonIntervModify.Enabled = false;
            buttonDeleteInterv.Enabled = false;

            buttonModifyTech.Enabled = false;
            buttonDelTech.Enabled = false;

            buttonModifMat.Enabled = false;
            buttonDeleteMat.Enabled = false;

            buttonModifyClient.Enabled = false;
            buttonDelClient.Enabled = false;

            loadLogin();
            fillGridViewMat();
            fillComboBoxMat();
            fillListBoxClient();
            fillListBoxTech();
            fillDataGridIntervPrevue();
            fillDataGridIntervPassee();
        }

        // -----------------------------------------------------------------------------------
        // ------------------------GESTION LISTBOX CLIENTS / TECHNICIENS----------------------
        // -----------------------------------------------------------------------------------

        public static int selectedTechIndex, selectedClientIndex;
        public static string selectedTechNom, selectedClientNom, selectedN_client, selectedAdresse, selectedMail, selectedTel;
        private void listBoxClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                itemClient selectedClient = (itemClient)listBoxClient.Items[listBoxClient.SelectedIndex];
                selectedClientIndex = selectedClient.ID;
                selectedClientNom = selectedClient.nom;
                selectedN_client = selectedClient.n_client;
                selectedAdresse = selectedClient.adresse;
                selectedMail = selectedClient.mail;
                selectedTel = selectedClient.telephone;
                
                buttonModifyTech.Enabled = false;
                buttonDelTech.Enabled = false;

                buttonModifMat.Enabled = false;
                buttonDeleteMat.Enabled = false;

                buttonIntervModify.Enabled = false;
                buttonDeleteInterv.Enabled = false;

                buttonModifyClient.Enabled = true;
                buttonDelClient.Enabled = true;
                             
                dataGridViewMateriel.ClearSelection(); // CLEAR EVERY SELECTION IN OTHER DATAGRIDVIEW
                dataGridViewOldInterv.ClearSelection(); // -------------------------------------------
                dataGridViewNewInterv.ClearSelection();
                listBoxTech.ClearSelected();

                toolStripStatusLabelSelectedCell.Text = "";
            }
            catch
            {
                return;
            }
        }
        private void buttonAddClient_Click(object sender, EventArgs e)
        {
            FormAddClient formAddClient = new FormAddClient();
            DialogResult dresult = formAddClient.ShowDialog();
            refresh();
        }
        private void buttonModifyClient_Click(object sender, EventArgs e)
        {
            FormUpdateClient formUpdateClient = new FormUpdateClient();
            DialogResult drUpdateClient = formUpdateClient.ShowDialog();
            if (drUpdateClient == DialogResult.OK)
            {
                helper.query
                    ("UPDATE CLIENT SET " +
                        "NOM = '" + formUpdateClient.newNom + 
                        "', NUM_CLIENT = '" + formUpdateClient.newNClient +
                        "', ADRESSE = '" + formUpdateClient.newAdresse +
                        "', MAIL = '" + formUpdateClient.newMail +
                        "', TELEPHONE = '" + formUpdateClient.newTel +
                        "' WHERE ID_CLIENT = '" + selectedClientIndex + "';");

                refresh();
            }
        }
        private void buttonDelClient_Click(object sender, EventArgs e)
        {
            helper.query("DELETE FROM CLIENT WHERE ID_CLIENT = '" + selectedClientIndex + "';");
   
            refresh();
        }

        private void listBoxTech_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                itemTech selectedTech = (itemTech)listBoxTech.Items[listBoxTech.SelectedIndex];
                selectedTechIndex = selectedTech.ID;
                selectedTechNom = selectedTech.nom;

                buttonModifyTech.Enabled = true;
                buttonDelTech.Enabled = true;

                buttonModifMat.Enabled = false;
                buttonDeleteMat.Enabled = false;

                buttonIntervModify.Enabled = false;
                buttonDeleteInterv.Enabled = false;

                buttonModifyClient.Enabled = false;
                buttonDelClient.Enabled = false;

                dataGridViewMateriel.ClearSelection(); // CLEAR EVERY SELECTION IN OTHER DATAGRIDVIEW
                dataGridViewOldInterv.ClearSelection(); // -------------------------------------------
                dataGridViewNewInterv.ClearSelection();
                listBoxClient.ClearSelected();

                toolStripStatusLabelSelectedCell.Text = "";
            }
            catch
            {   
                return;
            }
        }
        private void buttonAddTech_Click(object sender, EventArgs e)
        {
            FormAddTech formAddTech = new FormAddTech();
            DialogResult dresult = formAddTech.ShowDialog();
            refresh();
        }
        private void buttonModifyTech_Click(object sender, EventArgs e)
        {
            FormModifTech formModifTech = new FormModifTech();
            DialogResult drModifyTech = formModifTech.ShowDialog();
            if (drModifyTech == DialogResult.OK)
            {
                helper.query("UPDATE TECHNICIEN SET " +
                        "NOM = '" + formModifTech.newNom +
                        "' WHERE ID_TECHNICIEN = '" + selectedTechIndex + "';");

                refresh();
            }
        }
        private void buttonDelTech_Click(object sender, EventArgs e)
        {
            helper.query("DELETE FROM TECHNICIEN WHERE ID_TECHNICIEN = '" + selectedTechIndex + "';");

            refresh();
        }
        //---------------------------------------------------------------------------------------------
        // ----------------------------------GESTION DATAGRIDVIEW MATERIEL-----------------------------
        //---------------------------------------------------------------------------------------------

        //--------------------------------- BOUTON AJOUTER UN MATERIEL --------------------------------
        private void buttonAddMat_Click(object sender, EventArgs e)
        {
            int checkInput = 0;
            labelMateriel formAddMateriel = new labelMateriel();
            DialogResult drAddMateriel = formAddMateriel.ShowDialog();
            if (drAddMateriel == DialogResult.OK)
            {
                if (formAddMateriel.nom != "")
                    checkInput += 1;
                if (formAddMateriel.nSerie != "")
                    checkInput += 1;
                if (formAddMateriel.dateTimeInstall != null)
                    checkInput += 1;
                if (formAddMateriel.dateTimeMTBF != "")
                    checkInput += 1;
                if (formAddMateriel.marqueIndex != 0)
                    checkInput += 1;
                if (formAddMateriel.typeIndex != 0)
                    checkInput += 1;
                if (formAddMateriel.clientIndex != 0)
                    checkInput += 1;

                if (checkInput == 7)
                {
                    helper.query("INSERT INTO MATERIEL(NOM, N_SERIE, DATE_INSTALL, MTBF, ID_MARQUE, ID_TYPE, ID_CLIENT)" +
                        " VALUES('" + formAddMateriel.nom + "','" + formAddMateriel.nSerie + "','" + formAddMateriel.dateTimeInstall + "','" +
                        formAddMateriel.dateTimeMTBF + "','" + formAddMateriel.marqueIndex + "','" + formAddMateriel.typeIndex + "','" +
                        formAddMateriel.clientIndex + "');");

                    refresh();
                }
                else
                {
                    MessageBox.Show("Veuillez remplir tous les champs");
                }
                
            }
        }

        // --------------------------------- BOUTON MODIFIER LE MATERIEL ------------------------------
        private void buttonModifMat_Click(object sender, EventArgs e)
        {
            int checkInput = 0;
            if (id_mat == 0)
            {
                MessageBox.Show("Sélectionnez un ID");
            }
            else
            {
                FormUpdateMateriel formUpdateMateriel = new FormUpdateMateriel();
                DialogResult drUpdateMateriel = formUpdateMateriel.ShowDialog();
                if (drUpdateMateriel == DialogResult.OK)
                {
                    if (formUpdateMateriel.nom != "")
                        checkInput += 1;
                    if (formUpdateMateriel.nSerie != "")
                        checkInput += 1;
                    if (formUpdateMateriel.dateTimeInstall != null)
                        checkInput += 1;
                    if (formUpdateMateriel.dateTimeMTBF != "")
                        checkInput += 1;
                    if (formUpdateMateriel.marqueIndex != 0)
                        checkInput += 1;
                    if (formUpdateMateriel.typeIndex != 0)
                        checkInput += 1;
                    if (formUpdateMateriel.clientIndex != 0)
                        checkInput += 1;

                    if (checkInput == 7)
                    {
                        helper.query
                            ("UPDATE MATERIEL SET " +
                            "NOM = '" + formUpdateMateriel.nom +
                            "', N_SERIE = '" + formUpdateMateriel.nSerie +
                            "', DATE_INSTALL = '" + formUpdateMateriel.dateTimeInstall +
                            "', MTBF = '" + formUpdateMateriel.dateTimeMTBF +
                            "', ID_MARQUE = '" + formUpdateMateriel.marqueIndex +
                            "', ID_TYPE = '" + formUpdateMateriel.typeIndex +
                            "', ID_CLIENT = '" + formUpdateMateriel.clientIndex +
                            "' WHERE ID_MATERIEL = '" + id_mat + "';");

                        refresh();
                    }
                    else
                    {
                        MessageBox.Show("Veuillez remplir tous les champs");
                    }
                }
            }
        }

        //-------------------------------- BOUTON SUPPRIMER LE MATERIEL -------------------------------

        private void buttonDeleteMat_Click(object sender, EventArgs e)
        {
            if (id_mat == 0)
            {
                MessageBox.Show("Sélectionnez un ID");
            }
            else
            {
                helper.query
                        ("DELETE FROM MATERIEL WHERE ID_MATERIEL = '" + id_mat + "';");

                refresh();
            }
        }

        public int id_mat;
        public static int dateTimeMTBF;
        public static string nom, nSerie;
        public static int clientIndex, typeIndex, marqueIndex;

        public static DateTime dateTimeInstall;

        private int countFailedClick = 0;
        private void dataGridViewMateriel_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            buttonIntervModify.Enabled = false;
            buttonDeleteInterv.Enabled = false;

            buttonDelClient.Enabled = false;
            buttonModifyClient.Enabled = false;

            buttonDelTech.Enabled = false;
            buttonModifyTech.Enabled = false;

            buttonModifMat.Enabled = true;
            buttonDeleteMat.Enabled = true;

            if (dataGridViewMateriel.CurrentCell.ColumnIndex == 0)
            {
                if (e.RowIndex == -1) // AVOID EXCEPTION INDEX OUT OF RANGE 
                {
                    return;
                }
                else
                {
                    toolStripStatusLabelSelectedCell.Text = "ID sélectionné : " + dataGridViewMateriel.Rows[e.RowIndex].Cells[0].Value.ToString();

                    id_mat = Convert.ToInt32(dataGridViewMateriel.Rows[e.RowIndex].Cells[0].Value);
                    nom = dataGridViewMateriel.Rows[e.RowIndex].Cells[1].Value.ToString();
                    nSerie = dataGridViewMateriel.Rows[e.RowIndex].Cells[2].Value.ToString();
                    dateTimeInstall = (DateTime)dataGridViewMateriel.Rows[e.RowIndex].Cells[3].Value;
                    dateTimeMTBF = Convert.ToInt32(dataGridViewMateriel.Rows[e.RowIndex].Cells[4].Value);
                    marqueIndex = Convert.ToInt32(dataGridViewMateriel.Rows[e.RowIndex].Cells[10].Value);
                    typeIndex = Convert.ToInt32(dataGridViewMateriel.Rows[e.RowIndex].Cells[9].Value);
                    clientIndex = Convert.ToInt32(dataGridViewMateriel.Rows[e.RowIndex].Cells[8].Value);
                    

                    dataGridViewNewInterv.ClearSelection(); // CLEAR EVERY SELECTION IN OTHER DATAGRIDVIEW
                    dataGridViewOldInterv.ClearSelection(); // -------------------------------------------
                    listBoxTech.ClearSelected();
                    listBoxClient.ClearSelected();

                    countFailedClick = 0;
                }
            }
            else
            {
                id_mat = 0;
                countFailedClick += 1;
                dataGridViewMateriel.CurrentCell = null;
                toolStripStatusLabelSelectedCell.Text = "Sélectionnez un ID";

                if (countFailedClick == 3)
                {
                    MessageBox.Show("Veuillez sélectionner un ID");
                    countFailedClick = 0;
                }
            }

        }

        //---------------------------------------------------------------------------------------------
        //------------------------------GESTION DATAGRIDVIEW INTERVENTIONS-----------------------------
        //---------------------------------------------------------------------------------------------

        public int id_Interv;
        public DateTime dateNewInterv;

        public int techIndex, matIndex;
        public string commentaireNewInterv;

        private void dataGridViewNewInterv_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            buttonModifMat.Enabled = false;
            buttonDeleteMat.Enabled = false;

            buttonModifyTech.Enabled = false;
            buttonDelTech.Enabled = false;

            buttonModifMat.Enabled = false;
            buttonDeleteMat.Enabled = false;

            buttonIntervModify.Enabled = true;
            buttonDeleteInterv.Enabled = true;

            buttonModifyClient.Enabled = false;
            buttonDelClient.Enabled = false;


            if (dataGridViewNewInterv.CurrentCell.ColumnIndex == 0)
            {  
                if (e.RowIndex == -1) // AVOID EXCEPTION INDEX OUT OF RANGE 
                {
                    return;
                }
                else
                {
                    toolStripStatusLabelSelectedCell.Text = "ID sélectionné : " + dataGridViewNewInterv.Rows[e.RowIndex].Cells[0].Value.ToString();

                    id_Interv = Convert.ToInt32(dataGridViewNewInterv.Rows[e.RowIndex].Cells[0].Value);
                    dateNewInterv = (DateTime)dataGridViewNewInterv.Rows[e.RowIndex].Cells[1].Value;
                    commentaireNewInterv = dataGridViewNewInterv.Rows[e.RowIndex].Cells[2].Value.ToString();
                    techIndex = Convert.ToInt32(dataGridViewNewInterv.Rows[e.RowIndex].Cells[3].Value);
                    matIndex = Convert.ToInt32(dataGridViewNewInterv.Rows[e.RowIndex].Cells[4].Value);

                    dateTimePickerInterv.Value = dateNewInterv;
                    textBoxIntervCom.Text = commentaireNewInterv;

                    // SET TECHNICIEN'S VALUE FOR SELECTED INDEX
                    SqlDataReader drtech = helper.selectQuery("SELECT * FROM TECHNICIEN");

                    while (drtech.Read())
                    {
                        int id = Convert.ToInt32(drtech["ID_TECHNICIEN"]);
                        string nom = drtech["NOM"].ToString();

                        itemTech ic = new itemTech(id, nom);

                        if (id == techIndex)
                        {
                            comboBoxIntervTech.Text = ic.ToString();
                        }
                    }

                    helper.conn.Close();

                    //SET MATERIEL'S VALUE FOR SELECTED INDEX
                    SqlDataReader reader = helper.selectQuery("SELECT * FROM MATERIEL");

                    while (reader.Read())
                    {
                        int id = Convert.ToInt32(reader["ID_MATERIEL"]);
                        string nom = reader["NOM"].ToString();
                        string n_serie = reader["N_SERIE"].ToString();
                        DateTime dateMat = (DateTime)reader["DATE_INSTALL"];
                        string MTBF = reader["MTBF"].ToString();
                        int marqueIndex = Convert.ToInt32(reader["ID_MARQUE"]);
                        int typeIndex = Convert.ToInt32(reader["ID_TYPE"]);
                        int clientIndex = Convert.ToInt32(reader["ID_CLIENT"]);

                        itemMateriel im = new itemMateriel(id, nom, n_serie, MTBF, clientIndex, typeIndex, marqueIndex, dateMat);

                        if (id == matIndex)
                        {
                            comboBoxIntervMat.Text = im.ToString();
                        }
                    }

                    helper.conn.Close();

                    //----------------------------------------------

                    dataGridViewMateriel.ClearSelection(); // CLEAR EVERY SELECTION IN OTHER DATAGRIDVIEW
                    dataGridViewOldInterv.ClearSelection(); // -------------------------------------------
                    listBoxClient.ClearSelected();
                    listBoxTech.ClearSelected();
                   

                    countFailedClick = 0;
                }
            }
            else
            {
                id_Interv = 0;
                countFailedClick += 1;
                dataGridViewNewInterv.CurrentCell = null;
                toolStripStatusLabelSelectedCell.Text = "Sélectionnez un ID";

                if (countFailedClick == 3)
                {
                    MessageBox.Show("Veuillez sélectionner un ID");
                    countFailedClick = 0;
                }
            }
        }

        private void dataGridViewOldInterv_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            buttonModifMat.Enabled = false;
            buttonDeleteMat.Enabled = false;
            buttonIntervModify.Enabled = true; // GIVE THE POSSIBILITY TO CLICK ON "MODIFIER" BUTTON 
            buttonDeleteInterv.Enabled = true; // GIVE THE POSSIBILITY TO CLICK ON "SUPPRIMER" BUTTON

            if (dataGridViewOldInterv.CurrentCell.ColumnIndex == 0)
            {
                if (e.RowIndex == -1) // AVOID EXCEPTION INDEX OUT OF RANGE 
                {
                    return;
                }
                else
                {
                    toolStripStatusLabelSelectedCell.Text = "ID sélectionné : " + dataGridViewOldInterv.Rows[e.RowIndex].Cells[0].Value.ToString();

                    id_Interv = Convert.ToInt32(dataGridViewOldInterv.Rows[e.RowIndex].Cells[0].Value);
                    dateNewInterv = (DateTime)dataGridViewOldInterv.Rows[e.RowIndex].Cells[1].Value;
                    commentaireNewInterv = dataGridViewOldInterv.Rows[e.RowIndex].Cells[2].Value.ToString();
                    techIndex = Convert.ToInt32(dataGridViewOldInterv.Rows[e.RowIndex].Cells[3].Value);
                    matIndex = Convert.ToInt32(dataGridViewOldInterv.Rows[e.RowIndex].Cells[4].Value);

                    dateTimePickerInterv.Value = dateNewInterv;
                    textBoxIntervCom.Text = commentaireNewInterv;

                    // SET TECHNICIEN'S VALUE FOR SELECTED INDEX
                    SqlDataReader drtech = helper.selectQuery("SELECT * FROM TECHNICIEN");

                    while (drtech.Read())
                    {
                        int id = Convert.ToInt32(drtech["ID_TECHNICIEN"]);
                        string nom = drtech["NOM"].ToString();

                        itemTech it = new itemTech(id, nom);

                        if (id == techIndex)
                        {
                            comboBoxIntervTech.Text = it.ToString();
                        }
                    }

                    helper.conn.Close();

                    //SET MATERIEL'S VALUE FOR SELECTED INDEX
                    SqlDataReader reader = helper.selectQuery("SELECT * FROM MATERIEL");

                    while (reader.Read())
                    {
                        int id = Convert.ToInt32(reader["ID_MATERIEL"]);
                        string nom = reader["NOM"].ToString();
                        string n_serie = reader["N_SERIE"].ToString();
                        DateTime dateMat = (DateTime)reader["DATE_INSTALL"];
                        string MTBF = reader["MTBF"].ToString();
                        int marqueIndex = Convert.ToInt32(reader["ID_MARQUE"]);
                        int typeIndex = Convert.ToInt32(reader["ID_TYPE"]);
                        int clientIndex = Convert.ToInt32(reader["ID_CLIENT"]);

                        itemMateriel im = new itemMateriel(id, nom, n_serie, MTBF, clientIndex, typeIndex, marqueIndex, dateMat);

                        if (id == matIndex)
                        {
                            comboBoxIntervMat.Text = im.ToString();
                        }
                    }

                    helper.conn.Close();

                    dataGridViewMateriel.ClearSelection(); // CLEAR EVERY SELECTION IN OTHER DATAGRIDVIEW
                    dataGridViewNewInterv.ClearSelection(); // -------------------------------------------

                    buttonIntervModify.Enabled = true; // GIVE THE POSSIBILITY TO CLICK ON "MODIFIER" BUTTON 
                    buttonDeleteInterv.Enabled = true; // GIVE THE POSSIBILITY TO CLICK ON "SUPPRIMER" BUTTON

                    

                    countFailedClick = 0;
                }
            }
            else
            {
                id_Interv = 0;
                countFailedClick += 1;
                dataGridViewOldInterv.CurrentCell = null;
                toolStripStatusLabelSelectedCell.Text = "Sélectionnez un ID";

                if (countFailedClick == 3)
                {
                    MessageBox.Show("Veuillez sélectionner un ID");
                    countFailedClick = 0;
                }
            }
        }

        // ------------------------ BUTTON "AJOUTER" INTERVENTION -------------------------------------

        public int selectedTechIntervIndex, selectedMatIntervIndex;

        private void comboBoxIntervTech_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                itemTech selectedTechAddInterv = (itemTech)comboBoxIntervTech.Items[comboBoxIntervTech.SelectedIndex];
                selectedTechIntervIndex = selectedTechAddInterv.ID;
            }
            catch
            {
                return;
            }
        }
        private void comboBoxIntervMat_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                itemMateriel selectedMatAddInterv = (itemMateriel)comboBoxIntervMat.Items[comboBoxIntervMat.SelectedIndex];
                selectedMatIntervIndex = selectedMatAddInterv.id;
            }
            catch
            {
                return;
            }
        }
        private void buttonAddInterv_Click(object sender, EventArgs e)
        {
            if ((selectedTechIntervIndex != 0) && (selectedMatIntervIndex != 0))
            {
                helper.query
                        ("INSERT INTO INTERVENTION(DATE, COMMENTAIRE, ID_TECHNICIEN, ID_MATERIEL)" +
                            " VALUES('" +
                            dateTimePickerInterv.Value + "','" +
                            textBoxIntervCom.Text + "','" +
                            selectedTechIntervIndex + "','" +
                            selectedMatIntervIndex + "');");

                refresh();
            }
            else
            {
                toolStripStatusLabelSelectedCell.Text = "Veuillez remplir tous les champs nécessaires";

                buttonIntervModify.Enabled = false;
                buttonDeleteInterv.Enabled = false;

                buttonModifyTech.Enabled = false;
                buttonDelTech.Enabled = false;

                buttonModifyClient.Enabled = false;
                buttonDelClient.Enabled = false;

                buttonModifMat.Enabled = false;
                buttonDeleteMat.Enabled = false;

                dataGridViewMateriel.ClearSelection();
                listBoxClient.ClearSelected();
                listBoxTech.ClearSelected();
            }
        }

        // ------------------------ BUTTON "SUPPRIMER" INTERVENTION -----------------------------------
        private void buttonDeleteInterv_Click(object sender, EventArgs e)
        {
            helper.query
                    ("DELETE FROM INTERVENTION WHERE ID_INTERVENTION = '" + id_Interv + "';");

            selectedTechIntervIndex = 0;
            selectedMatIntervIndex = 0;

            refresh();
        }

        // ------------------------- BUTTON "MODIFIER" INTERVENTION -----------------------------------

        private void buttonIntervModify_Click(object sender, EventArgs e)
        {
            itemTech tech = (itemTech)comboBoxIntervTech.SelectedItem;
            this.techIndex = tech.ID;

            itemMateriel itemMat = (itemMateriel)comboBoxIntervMat.SelectedItem;
            this.matIndex = itemMat.id;

            helper.query
                    ("UPDATE INTERVENTION SET " +
                    "DATE = '" + dateTimePickerInterv.Value +
                    "', COMMENTAIRE = '" + textBoxIntervCom.Text +
                    "', ID_TECHNICIEN = '" + techIndex +
                    "', ID_MATERIEL = '" + matIndex +
                    "' WHERE ID_INTERVENTION = '" + id_Interv + "';");

            refresh();
        }

        //---------------------------------------------------------------------------------------------
        // ---------------------------------- RAFRAÎCHIR LA PAGE --------------------------------------
        //---------------------------------------------------------------------------------------------
        private void refresh()
        {

            listBoxClient.Items.Clear();
            listBoxTech.Items.Clear();

            comboBoxIntervMat.Text = "";
            comboBoxIntervTech.Text = "";
            selectedTechIntervIndex = 0;
            selectedMatIntervIndex = 0;

            textBoxIntervCom.Text = null;
            dateTimePickerInterv.Value = DateTime.Now;

            comboBoxIntervTech.Items.Clear();
            comboBoxIntervMat.Items.Clear();

            buttonIntervModify.Enabled = false;
            buttonDeleteInterv.Enabled = false;

            buttonModifyTech.Enabled = false;
            buttonDelTech.Enabled = false;

            buttonModifyClient.Enabled = false;
            buttonDelClient.Enabled = false;

            buttonModifMat.Enabled = false;
            buttonDeleteMat.Enabled = false;

            toolStripStatusLabelSelectedCell.Text = "";

            fillGridViewMat();
            fillComboBoxMat();
            fillListBoxClient();
            fillListBoxTech();
            fillDataGridIntervPrevue();
            fillDataGridIntervPassee();

        }
        private void rafraîchirLaPageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStripStatusLabelTimeRefresh.Text = "Last update : " + DateTime.Now.ToString();
            refresh();
        }

        // -----------------------------------------------------------------------------------------
        // -----------------------------------------------------------------------------------------
        // -----------------------------------------------------------------------------------------

        // --------------------------------- ADMINISTRATEUR MODE -----------------------------------

        private void utilisateursToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAdmin formAdmin = new FormAdmin("utilisateur");
            formAdmin.ShowDialog();
        }
        private void marquesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAdmin formAdmin = new FormAdmin("marque");
            formAdmin.ShowDialog();
            refresh();
        }
        private void typesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormType formType = new FormType();
            formType.ShowDialog();
        }

        // -----------------------------------------------------------------------------------------
        private void seDéconnecterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void quitterGMSYY2022ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
    