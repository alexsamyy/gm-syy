﻿namespace WindowsFormsAppGestion
{
    partial class FormAddClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNomClient = new System.Windows.Forms.TextBox();
            this.labelNomClient = new System.Windows.Forms.Label();
            this.labelTitleAddTech = new System.Windows.Forms.Label();
            this.buttonCancelClient = new System.Windows.Forms.Button();
            this.buttonAddClient = new System.Windows.Forms.Button();
            this.textBoxNumClient = new System.Windows.Forms.TextBox();
            this.labelNumClient = new System.Windows.Forms.Label();
            this.textBoxAdresseClient = new System.Windows.Forms.TextBox();
            this.labelAdresseClient = new System.Windows.Forms.Label();
            this.textBoxMailClient = new System.Windows.Forms.TextBox();
            this.labelMailClient = new System.Windows.Forms.Label();
            this.textBoxTelClient = new System.Windows.Forms.TextBox();
            this.labelTelClient = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxNomClient
            // 
            this.textBoxNomClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNomClient.Location = new System.Drawing.Point(52, 101);
            this.textBoxNomClient.Name = "textBoxNomClient";
            this.textBoxNomClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxNomClient.TabIndex = 9;
            // 
            // labelNomClient
            // 
            this.labelNomClient.AutoSize = true;
            this.labelNomClient.Location = new System.Drawing.Point(51, 82);
            this.labelNomClient.Name = "labelNomClient";
            this.labelNomClient.Size = new System.Drawing.Size(39, 16);
            this.labelNomClient.TabIndex = 8;
            this.labelNomClient.Text = "Nom ";
            // 
            // labelTitleAddTech
            // 
            this.labelTitleAddTech.AutoSize = true;
            this.labelTitleAddTech.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleAddTech.Location = new System.Drawing.Point(160, 36);
            this.labelTitleAddTech.Name = "labelTitleAddTech";
            this.labelTitleAddTech.Size = new System.Drawing.Size(168, 25);
            this.labelTitleAddTech.TabIndex = 7;
            this.labelTitleAddTech.Text = "Ajouter un client";
            // 
            // buttonCancelClient
            // 
            this.buttonCancelClient.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancelClient.Location = new System.Drawing.Point(369, 433);
            this.buttonCancelClient.Name = "buttonCancelClient";
            this.buttonCancelClient.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelClient.TabIndex = 6;
            this.buttonCancelClient.Text = "Annuler";
            this.buttonCancelClient.UseVisualStyleBackColor = true;
            // 
            // buttonAddClient
            // 
            this.buttonAddClient.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonAddClient.Location = new System.Drawing.Point(288, 433);
            this.buttonAddClient.Name = "buttonAddClient";
            this.buttonAddClient.Size = new System.Drawing.Size(75, 23);
            this.buttonAddClient.TabIndex = 5;
            this.buttonAddClient.Text = "Valider";
            this.buttonAddClient.UseVisualStyleBackColor = true;
            this.buttonAddClient.Click += new System.EventHandler(this.buttonAddClient_Click);
            // 
            // textBoxNumClient
            // 
            this.textBoxNumClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNumClient.Location = new System.Drawing.Point(52, 159);
            this.textBoxNumClient.Name = "textBoxNumClient";
            this.textBoxNumClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxNumClient.TabIndex = 11;
            // 
            // labelNumClient
            // 
            this.labelNumClient.AutoSize = true;
            this.labelNumClient.Location = new System.Drawing.Point(51, 140);
            this.labelNumClient.Name = "labelNumClient";
            this.labelNumClient.Size = new System.Drawing.Size(89, 16);
            this.labelNumClient.TabIndex = 10;
            this.labelNumClient.Text = "Numéro client";
            // 
            // textBoxAdresseClient
            // 
            this.textBoxAdresseClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAdresseClient.Location = new System.Drawing.Point(52, 226);
            this.textBoxAdresseClient.Name = "textBoxAdresseClient";
            this.textBoxAdresseClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxAdresseClient.TabIndex = 13;
            // 
            // labelAdresseClient
            // 
            this.labelAdresseClient.AutoSize = true;
            this.labelAdresseClient.Location = new System.Drawing.Point(51, 207);
            this.labelAdresseClient.Name = "labelAdresseClient";
            this.labelAdresseClient.Size = new System.Drawing.Size(58, 16);
            this.labelAdresseClient.TabIndex = 12;
            this.labelAdresseClient.Text = "Adresse";
            // 
            // textBoxMailClient
            // 
            this.textBoxMailClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMailClient.Location = new System.Drawing.Point(52, 292);
            this.textBoxMailClient.Name = "textBoxMailClient";
            this.textBoxMailClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxMailClient.TabIndex = 15;
            // 
            // labelMailClient
            // 
            this.labelMailClient.AutoSize = true;
            this.labelMailClient.Location = new System.Drawing.Point(51, 273);
            this.labelMailClient.Name = "labelMailClient";
            this.labelMailClient.Size = new System.Drawing.Size(98, 16);
            this.labelMailClient.TabIndex = 14;
            this.labelMailClient.Text = "Adresse e-mail";
            // 
            // textBoxTelClient
            // 
            this.textBoxTelClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTelClient.Location = new System.Drawing.Point(52, 359);
            this.textBoxTelClient.Name = "textBoxTelClient";
            this.textBoxTelClient.Size = new System.Drawing.Size(392, 27);
            this.textBoxTelClient.TabIndex = 17;
            // 
            // labelTelClient
            // 
            this.labelTelClient.AutoSize = true;
            this.labelTelClient.Location = new System.Drawing.Point(51, 340);
            this.labelTelClient.Name = "labelTelClient";
            this.labelTelClient.Size = new System.Drawing.Size(73, 16);
            this.labelTelClient.TabIndex = 16;
            this.labelTelClient.Text = "Téléphone";
            // 
            // FormAddClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 478);
            this.Controls.Add(this.textBoxTelClient);
            this.Controls.Add(this.labelTelClient);
            this.Controls.Add(this.textBoxMailClient);
            this.Controls.Add(this.labelMailClient);
            this.Controls.Add(this.textBoxAdresseClient);
            this.Controls.Add(this.labelAdresseClient);
            this.Controls.Add(this.textBoxNumClient);
            this.Controls.Add(this.labelNumClient);
            this.Controls.Add(this.textBoxNomClient);
            this.Controls.Add(this.labelNomClient);
            this.Controls.Add(this.labelTitleAddTech);
            this.Controls.Add(this.buttonCancelClient);
            this.Controls.Add(this.buttonAddClient);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAddClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Ajouter un client";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxNomClient;
        private System.Windows.Forms.Label labelNomClient;
        private System.Windows.Forms.Label labelTitleAddTech;
        private System.Windows.Forms.Button buttonCancelClient;
        private System.Windows.Forms.Button buttonAddClient;
        private System.Windows.Forms.TextBox textBoxNumClient;
        private System.Windows.Forms.Label labelNumClient;
        private System.Windows.Forms.TextBox textBoxAdresseClient;
        private System.Windows.Forms.Label labelAdresseClient;
        private System.Windows.Forms.TextBox textBoxMailClient;
        private System.Windows.Forms.Label labelMailClient;
        private System.Windows.Forms.TextBox textBoxTelClient;
        private System.Windows.Forms.Label labelTelClient;
    }
}